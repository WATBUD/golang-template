package main

import (
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"

	"beango.visualstudio.com/BeanGoAPP/caerus/database"
	log "beango.visualstudio.com/BeanGoAPP/caerus/logger"
	"beango.visualstudio.com/BeanGoAPP/caerus/redis"
	"beango.visualstudio.com/BeanGoAPP/caerus/zookeeper"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/configs"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/kafka"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/repository"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/worker"
	messagebuilderfactory "beango.visualstudio.com/BeanGoAPP/stork/internal/worker/message_builder_factory" // nolint: lll
	"beango.visualstudio.com/BeanGoAPP/stork/internal/worker/message_builder_factory/builder"
	_ "beango.visualstudio.com/BeanGoAPP/stork/internal/worker/message_builder_factory/builder/loadall" // nolint: lll
	_ "github.com/joho/godotenv/autoload"
	"github.com/sirupsen/logrus"
)

func main() {
	config, err := configs.New()
	if err != nil {
		panic(err)
	}

	logger, err := log.NewRDLogger(
		config.Server.Name, config.Logs.Threshold, os.Stdout,
	)
	if err != nil {
		panic(err)
	}

	redis := redis.NewRedis(
		strings.Split(config.Connections.Redis.Hosts, ","),
		config.Connections.Redis.Password,
		config.Connections.Redis.PoolSize,
	)

	zookeeper, err := zookeeper.NewZookeeper(
		strings.Split(config.Connections.Zookeeper.Hosts, ","),
		time.Duration(config.Connections.Zookeeper.ConnectionTimeout)*time.Second,
		time.Duration(config.Connections.Zookeeper.SessionTimeout)*time.Second,
	)
	if err != nil {
		logger.Fatalf("new zookeeper error: %s", err)
	}

	machineID, err := zookeeper.GetValidEphemeral("/beanfun/snowflake/stork")
	if err != nil {
		logger.Fatalf("get valid machine id error: %s", err)
	}
	logger.Infof("machine id %d", machineID)

	db, err := database.NewPostgresql(
		config.Connections.Postgresql.Host,
		config.Connections.Postgresql.DB,
		config.Connections.Postgresql.User,
		config.Connections.Postgresql.Password,
		config.Connections.Postgresql.MaxOpen,
		config.Connections.Postgresql.MaxIdle,
		config.Connections.PGBouncer.Enabled,
	)
	if err != nil {
		logger.Fatalf("new postgresql error: %s", err)
	}

	repo := repository.NewNotificationRepo(logger)

	factory, err := messagebuilderfactory.NewMessageBuilderFactory(builder.AllBuilders, logger)
	if err != nil {
		logger.Fatalf("new message builder factory error: %s", err)
	}

	kafkaHosts := strings.Split(config.Connections.Kafka.Hosts, ",")
	kafkaTopic := config.Connections.Kafka.Topic
	consumer := kafka.NewNotificationConsumer(kafkaHosts, kafkaTopic, "stork", logger)

	worker := worker.NewWorker(factory, db, redis, consumer, repo, logger)
	setupSignalHandler(worker, db, consumer, logger)
	logger.Infof("worker started")
	if err := worker.Run(); err != nil {
		logger.Fatalf("worker error: %s", err)
	}
	logger.Infof("worker stopped")
}

func setupSignalHandler(
	worker worker.Worker, db database.Database,
	consumer kafka.NotificationConsumer, logger logrus.FieldLogger,
) {
	sigs := make(chan os.Signal, 1)
	signal.Notify(sigs, syscall.SIGINT, syscall.SIGTERM)
	go func() {
		sig := <-sigs
		logger.Infof("got signal %d, shutting down worker", sig)
		worker.Stop()
		consumer.Close()
		db.Close()
	}()
}
