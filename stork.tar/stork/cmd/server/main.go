package main

import (
	"fmt"
	"net"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"

	"beango.visualstudio.com/BeanGoAPP/caerus/database"
	accesslog "beango.visualstudio.com/BeanGoAPP/caerus/grpc/interceptor/access_log"
	dbinterceptor "beango.visualstudio.com/BeanGoAPP/caerus/grpc/interceptor/database"
	log "beango.visualstudio.com/BeanGoAPP/caerus/logger"
	"beango.visualstudio.com/BeanGoAPP/caerus/redis"
	"beango.visualstudio.com/BeanGoAPP/caerus/snowflake"
	"beango.visualstudio.com/BeanGoAPP/caerus/zookeeper"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/configs"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/grpc"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/grpc/controller"
	lastresendcache "beango.visualstudio.com/BeanGoAPP/stork/internal/grpc/controller/last_resend_cache" // nolint: lll
	"beango.visualstudio.com/BeanGoAPP/stork/internal/kafka"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/repository"
	_ "github.com/joho/godotenv/autoload"
	"github.com/sirupsen/logrus"
	gogrpc "google.golang.org/grpc"
)

func main() {
	config, err := configs.New()
	if err != nil {
		panic(err)
	}

	logger, err := log.NewRDLogger(
		config.Server.Name, config.Logs.Threshold, os.Stdout,
	)
	if err != nil {
		panic(err)
	}

	zookeeper, err := zookeeper.NewZookeeper(
		strings.Split(config.Connections.Zookeeper.Hosts, ","),
		time.Duration(config.Connections.Zookeeper.ConnectionTimeout)*time.Second,
		time.Duration(config.Connections.Zookeeper.SessionTimeout)*time.Second,
	)
	if err != nil {
		logger.Fatalf("new zookeeper error: %s", err)
	}

	machineID, err := zookeeper.GetValidEphemeral("/beanfun/snowflake/stork")
	if err != nil {
		logger.Fatalf("get valid machine id error: %s", err)
	}
	logger.Infof("machine id %d", machineID)

	db, err := database.NewPostgresql(
		config.Connections.Postgresql.Host,
		config.Connections.Postgresql.DB,
		config.Connections.Postgresql.User,
		config.Connections.Postgresql.Password,
		config.Connections.Postgresql.MaxOpen,
		config.Connections.Postgresql.MaxIdle,
		config.Connections.PGBouncer.Enabled,
	)
	if err != nil {
		logger.Fatalf("new postgresql error: %s", err)
	}

	repo := repository.NewNotificationRepo(logger)
	kafkaHosts := strings.Split(config.Connections.Kafka.Hosts, ",")
	kafkaTopic := config.Connections.Kafka.Topic
	producer := kafka.NewNotificationProducer(kafkaHosts, kafkaTopic, logger)
	if err != nil {
		logger.Fatalf("new producer error: %s", err)
	}

	IDGenerator, err := snowflake.New(0, int64(machineID), snowflake.DefaultTimeFunc)
	if err != nil {
		logger.Fatalf("new snowflake error: %s", err)
	}
	clubController := controller.NewClubController(producer, IDGenerator, logger)
	resendFrom := time.Now().Add(-time.Duration(config.ResendDays) * 24 * time.Hour)

	redis := redis.NewRedis(
		strings.Split(config.Connections.Redis.Hosts, ","),
		config.Connections.Redis.Password,
		config.Connections.Redis.PoolSize,
	)
	lastResendCache := lastresendcache.NewLastResendCache(redis)
	commonController := controller.NewCommonController(
		repo, producer, resendFrom, config.ResendCount, lastResendCache, logger)
	healthController := controller.NewHealthController(db, logger)

	databaseInterceptor := dbinterceptor.NewDatabaseInterceptor(db, logger)
	accessLogger := log.NewAccessLogger(config.Server.Name, os.Stdout)
	accessLogInterceptor := accesslog.NewAccessLogInterceptor(accessLogger)
	server := grpc.NewGRPCServer(
		clubController, commonController, healthController,
		accessLogInterceptor.UnaryFunc,
		databaseInterceptor.UnaryFunc,
	)

	host := fmt.Sprintf(":%s", config.Server.Port)
	listener, err := net.Listen("tcp", host)
	if err != nil {
		logger.Fatalf("listen %s error: %s", host, err)
	}

	setupSignalHandler(server, db, producer, logger)
	logger.Infof("server started on %s", host)
	if err := server.Serve(listener); err != nil {
		logger.Fatalf("server error: %s", err)
	}
	logger.Infof("service stopped")
}

func setupSignalHandler(
	server *gogrpc.Server, db database.Database,
	producer kafka.NotificationProducer, logger logrus.FieldLogger,
) {
	sigs := make(chan os.Signal, 1)
	signal.Notify(sigs, syscall.SIGINT, syscall.SIGTERM)
	go func() {
		sig := <-sigs
		logger.Infof("got signal %d, shutting down server", sig)
		server.GracefulStop()
		producer.Close()
		db.Close()
	}()
}
