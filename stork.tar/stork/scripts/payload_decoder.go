package main

import (
	"encoding/base64"
	"encoding/json"
	"flag"
	"fmt"

	pb "beango.visualstudio.com/BeanGoAPP/stork/internal/gen/pb/notification"
	"google.golang.org/protobuf/proto"
)

func main() {
	raw := flag.String("payload", "", "encoded payload")
	flag.Parse()

	payload, err := base64.StdEncoding.DecodeString(*raw)
	if err != nil {
		panic(err)
	}

	metadata := pb.Notification{}
	err = proto.Unmarshal(payload, &metadata)
	if err != nil {
		panic(err)
	}

	beauty, err := json.MarshalIndent(metadata, "", "  ") // nolint: govet
	if err != nil {
		panic(err)
	}
	fmt.Println(string(beauty))
}
