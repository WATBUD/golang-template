
CREATE ROLE stork WITH LOGIN CREATEDB CREATEROLE PASSWORD 'XXX';

CREATE DATABASE stork
    WITH OWNER 'stork'
    ENCODING 'UTF8'
    LC_COLLATE = 'English_United States.1252'
    LC_CTYPE = 'English_United States.1252';

USE stork;

CREATE TABLE IF NOT EXISTS notification (
    request_id BIGINT NOT NULL,
    real_alias_id BIGINT NOT NULL,
    type VARCHAR(64) NOT NULL,
    subtype VARCHAR(64) NOT NULL,
    thumbnail_uri VARCHAR(255) NOT NULL,
    metadata JSONB NOT NULL,
    created_time BIGINT DEFAULT EXTRACT(epoch from CURRENT_TIMESTAMP(3)) * 1000,
    status SMALLINT DEFAULT 0,
    PRIMARY KEY ("request_id", "real_alias_id")
);

CREATE INDEX IF NOT EXISTS notification_status ON notification(status);
