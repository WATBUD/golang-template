# stork

## Design
[check here.](https://gamania-group.atlassian.net/wiki/spaces/BB/pages/5734401/Stork)


## How to add new notifications
* Assume that I'm going to add a new notification which type=foo, subtype=bar.
* add proto [here](https://dev.azure.com/beango/BeanGoAPP/_git/rocks?path=/notification).
    * `notification.proto` defines generic message that app will received and each metadata of individual subtype should be defined in `{type}_metadata.proto`.
    * `{type}_notification.proto` defines grpc interfaces for our internal services.
    * here are few steps:
        1. add new type and subtype enum in `notification.proto`.
            ```
            enum NotificationType {
                TypeUnknown = 0;
                TypeClub = 1;
            +    TypeFoo = 2;
            }

            enum NotificationSubtype {
                SubtypeUnknown = 0;
                SubtypeNewPost = 1;
                SubtypeReplyPost = 2;
                ...
            +   SubtypeBar = 99;
            }
            ```
        2. add metadata in `foo_metadata.proto`.
            ```
            message FooBarMetadata {
                string baz = 1;
            }
            ```
        3. add grpc interface in `foo_notification.proto`.
            ```
            service FooNotification {
                rpc NotifyBar(BarCommand) returns (BarResult);
            }

            message BarCommand {
                string baz = 1;
            }

            message BarResult {
                int64 id = 1;
            }
            ```
        4. let `FooBarMetadata` becomes oneof `notification.metadata`.
            ```
            message NotificationMetadata {
                oneof metadata_oneof {
                    ClubNewPostMetadata club_new_post = 1;
                    ...
                    FooBarMetadata foo_bar = 99;
                }
            }
            ```
* add model.type, model.subtype and model.metdata [here](https://dev.azure.com/beango/BeanGoAPP/_git/stork?path=/internal/model/model.go).
    * Using string instead of enum because I think it will more readable.
    ```
    const (
        TypeClub = "club"
    +    TypeFoo = "foo"

        SubtypeNewPost                   = "new_post"
    +    SubtypeBar = "bar"
    )
    ```
    ```
    type FooBarMetadata struct {
        Baz string `json:"baz"`
    }
    ```
* add message builder [here](https://dev.azure.com/beango/BeanGoAPP/_git/stork?path=/internal/worker/message_builder_factory/builder).
    * create package `foo` under `internal/worker/message_builder_factory/builder` and `bar.go` to implement a struct that satisfy `builder` interface
        * ONE FILE ONE BUILDER
    ```
    package foo

    import (
        ...
    )

    // XXX: don't forget init function or your builder won't be loaded.
    func init() {
        messageBuilder := &barMessageBuilder{}
        builder.AllBuilders = append(
            builder.AllBuilders, messageBuilder)
    }

    type barMessageBuilder struct {
    }

    func (b *barMessageBuilder) GetType() string {
        return model.TypeFoo
    }

    func (b *barMessageBuilder) GetSubtype() string {
        return model.SubtypeBar
    }

    func (b *barMessageBuilder) Build(
        notification *model.Notification,
    ) (proto.Message, error) {
        metadata := model.FooBarMetadata{}
        err := builder.MarshalMetadata(notification.Metadata, &metadata)
        if err != nil {
            return nil, errors.Wrap(err, "convert metadata error")
        }

        // XXX: make sure you return entire notification message not just metadata.
        return &pb.Notification{
            Id:           notification.RequestID,
            Type:         pb.NotificationType_TypeFoo,
            SubType:      pb.NotificationSubtype_SubtypeBar,
            ThumbnailUri: notification.ThumbnailURI,
            CreatedTime:  notification.CreatedTime,
            Metadata: &pb.NotificationMetadata{
                MetadataOneof: &pb.NotificationMetadata_FooBar{
                    FooBar: &pb.FooBarMetadata{
                        Baz:            metadata.Baz,
                    },
                },
            },
        }, nil
    }
    ```
* register builder [here](https://dev.azure.com/beango/BeanGoAPP/_git/stork?path=/internal/worker/message_builder_factory/builder/loadall)
    * use `import _` to trigger init functions to load all builders
    ```
    package loadall

    import (
        _ "beango.visualstudio.com/BeanGoAPP/stork/internal/worker/message_builder_factory/builder/club" // nolint: lll
        + _ "beango.visualstudio.com/BeanGoAPP/stork/internal/worker/message_builder_factory/builder/foo" // nolint: lll
    )
    ```
* run worker to see whether it works, worker will dump what it loaded.
```
~/workspace/stork$ go run cmd/worker/main.go
2021/12/11 01:23:59 re-submitting `0` credentials after reconnect
time="2021-12-11 01:23:59.782" level=info msg="machine id 48" hostname=localhost logger=default service=stork
time="2021-12-11 01:23:59.782" level=info msg="load club:application_accepted builder to message factoy" hostname=localhost logger=default service=stork
...
time="2021-12-11 01:23:59.782" level=info msg="load foo:bar builder to message factoy" hostname=localhost logger=default service=stork
```

## What will APP receive and how can I verify it
* APP will received message like below
    * path is a fixed value 'v1/notification'
    * payload is the encoded string
```
{
    "path":    "v1/notification",
    "payload": "CJjL+s+OzdzfFhABGAMiBUhlbGxvKPqV6KnaLzJkGmIIFBIFSGVsbG8YFCIFSGVsbG8oFDIkMDYwOWVmMDctY2Y5ZS00NzkyLTkyZWYtNTY1NmI5NGIyNDEyOiQ0MmJmYjMxYi05NTk4LTRjOGUtYmNkYi05MDdlYmVhZTM5NDVAAQ==",
}
```
* Here is a tool to decode payload string to verify our message builder
```
~/workspace/stork$ go run scripts/payload_decoder.go  -payload "CJjL+s+OzdzfFhABGAMiBUhlbGxvKPqV6KnaLzJkGmIIFBIFSGVsbG8YFCIFSGVsbG8oFDIkMDYwOWVmMDctY2Y5ZS00NzkyLTkyZWYtNTY1NmI5NGIyNDEyOiQ0MmJmYjMxYi05NTk4LTRjOGUtYmNkYi05MDdlYmVhZTM5NDVAAQ=="
{
  "id": 1639154584314095000,
  "type": 1,
  "sub_type": 3,
  "thumbnail_uri": "Hello",
  "created_time": 1639154584314,
  "metadata": {
    "MetadataOneof": {
      "ClubReplyComment": {
        "club_id": 20,
        "club_name": "Hello",
        "author_real_alias_id": 20,
        "author_nickname": "Hello",
        "post_id": 20,
        "comment_id": "0609ef07-cf9e-4792-92ef-5656b94b2412",
        "reply_id": "42bfb31b-9598-4c8e-bcdb-907ebeae3945",
        "is_official_club": true
      }
    }
  }
}
```
