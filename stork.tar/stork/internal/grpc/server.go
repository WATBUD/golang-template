package grpc

import (
	health "beango.visualstudio.com/BeanGoAPP/stork/internal/gen/pb/health"
	pb "beango.visualstudio.com/BeanGoAPP/stork/internal/gen/pb/notification"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/grpc/controller"
	"google.golang.org/grpc"
)

func NewGRPCServer(
	clubController *controller.ClubController, commonController *controller.CommonController,
	healthController *controller.HealthController,
	interceptors ...grpc.UnaryServerInterceptor,
) *grpc.Server {
	options := grpc.ChainUnaryInterceptor(interceptors...)
	server := grpc.NewServer(options)

	pb.RegisterClubNotificationServer(server, clubController)
	pb.RegisterCommonServer(server, commonController)
	health.RegisterHealthServer(server, healthController)
	return server
}
