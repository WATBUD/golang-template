package controller

import (
	"context"
	"fmt"
	"time"

	dbinterceptor "beango.visualstudio.com/BeanGoAPP/caerus/grpc/interceptor/database"
	pb "beango.visualstudio.com/BeanGoAPP/stork/internal/gen/pb/notification"
	lastresendcache "beango.visualstudio.com/BeanGoAPP/stork/internal/grpc/controller/last_resend_cache" // nolint: lll
	"beango.visualstudio.com/BeanGoAPP/stork/internal/kafka"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/repository"
	"github.com/golang/protobuf/ptypes/empty"
	"github.com/pkg/errors"
	"github.com/sirupsen/logrus"
)

func NewCommonController(
	repo repository.NotificationRepo, producer kafka.NotificationProducer,
	resendFrom time.Time, resendCount int,
	lastResendCache lastresendcache.LastResendCache,
	logger logrus.FieldLogger,
) *CommonController {
	return &CommonController{
		repo:            repo,
		producer:        producer,
		resendFrom:      resendFrom,
		resendCount:     resendCount,
		lastResendCache: lastResendCache,
		logger:          logger,
	}
}

type CommonController struct {
	repo            repository.NotificationRepo
	producer        kafka.NotificationProducer
	resendFrom      time.Time
	resendCount     int
	lastResendCache lastresendcache.LastResendCache
	logger          logrus.FieldLogger

	pb.UnimplementedCommonServer
}

func (c *CommonController) ResendNotifications(
	ctx context.Context, command *pb.ResendNotificationCommand,
) (*empty.Empty, error) {
	realAliasID := command.GetRealAliasId()
	notificationLastID := command.GetLastId()

	theSame := c.isSameAsLastResendCache(realAliasID, notificationLastID)
	if theSame {
		c.logger.Infof(
			"ignore resend request for alias %d due to last id not changed",
			realAliasID)
		return &empty.Empty{}, nil
	}

	conn, err := dbinterceptor.GetReadConnection(ctx)
	if err != nil {
		return nil, errors.Wrap(err, "get read connection error")
	}

	notifications, err := c.repo.Find(
		conn, realAliasID, notificationLastID,
		c.resendFrom.UnixMilli(), c.resendCount)
	if err != nil {
		c.logger.Errorf("find notifications for %d error: %s", realAliasID, err)
		return nil, errors.Wrap(err, "find notifications error")
	}

	count := 0
	for _, notification := range notifications {
		kafkaEvent := &model.KafkaEvent{Data: notification, Type: model.KafkaEventResend}
		err := c.producer.Produce(kafkaEvent)
		if err != nil {
			c.logger.Warnf("produce %d error: %s", notification.RequestID, err)
			continue
		}

		count++
	}

	if err := c.setLastResendCache(realAliasID, notificationLastID); err != nil {
		c.logger.Warnf("set last resend cache for real alias id %d error: %s", realAliasID, err)
	}

	if count > 0 {
		c.logger.Infof("resend %d notifications(%d) for real alias id %d",
			count, notificationLastID, realAliasID)
	}
	return &empty.Empty{}, nil
}

func (c *CommonController) isSameAsLastResendCache(
	realAliasID int64, notificationLastID int64,
) bool {
	lastIDInCache, err := c.lastResendCache.GetID(realAliasID)
	if err != nil {
		c.logger.Warnf("get last resend cache error: %s", err)
		return false
	}

	return lastIDInCache == notificationLastID
}

func (c *CommonController) setLastResendCache(
	realAliasID int64, notificationID int64,
) error {
	err := c.lastResendCache.SetID(realAliasID, notificationID)
	if err != nil {
		return fmt.Errorf("set last resend cache error: %w", err)
	}
	c.logger.Infof("set last resend cache %d for real alias id %d", notificationID, realAliasID)
	return nil
}
