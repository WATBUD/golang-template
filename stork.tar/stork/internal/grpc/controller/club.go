package controller

import (
	"context"
	"time"

	"beango.visualstudio.com/BeanGoAPP/caerus/snowflake"
	pb "beango.visualstudio.com/BeanGoAPP/stork/internal/gen/pb/notification"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/kafka"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"github.com/pkg/errors"
	"github.com/sirupsen/logrus"
)

func NewClubController(
	producer kafka.NotificationProducer,
	idGenerator snowflake.Generator,
	logger logrus.FieldLogger,
) *ClubController {
	return &ClubController{
		producer:    producer,
		logger:      logger,
		idGenerator: idGenerator,
	}
}

type ClubController struct {
	producer    kafka.NotificationProducer
	logger      logrus.FieldLogger
	idGenerator snowflake.Generator

	pb.UnimplementedClubNotificationServer
}

func (c *ClubController) NotifyNewPost(
	ctx context.Context, command *pb.NewPostCommand,
) (*pb.NewPostResult, error) {
	notification := makeNewPostNotification(c.idGenerator.Next(), command)
	requestID, err := c.produce(notification)
	if err != nil {
		return nil, errors.Wrap(err, "produce error")
	}
	return &pb.NewPostResult{
		Id: requestID,
	}, nil
}

func makeNewPostNotification(requestID int64, command *pb.NewPostCommand) *model.Notification {
	return &model.Notification{
		RequestID:          requestID,
		TargetRealAliasIDs: command.TargetRealAliasIds,
		Type:               model.TypeClub,
		Subtype:            model.SubtypeNewPost,
		ThumbnailURI:       command.ThumbnailUri,
		CreatedTime:        time.Now().UnixMilli(),
		Metadata: &model.NewPostMetadata{
			ClubID:            command.ClubId,
			ClubName:          command.ClubName,
			AuthorRealAliasID: command.AuthorRealAliasId,
			AuthorNickname:    command.AuthorNickname,
			PostID:            command.PostId,
			// deprecated
			//Content:           command.Content,
			IsOfficialClub: command.IsOfficialClub,
		},
	}
}

func (c *ClubController) NotifyReplyPost(
	ctx context.Context, command *pb.ReplyPostCommand,
) (*pb.ReplyPostResult, error) {
	notification := makeReplyPostNotification(c.idGenerator.Next(), command)
	requestID, err := c.produce(notification)
	if err != nil {
		return nil, errors.Wrap(err, "produce error")
	}

	return &pb.ReplyPostResult{
		Id: requestID,
	}, nil
}

func makeReplyPostNotification(requestID int64, command *pb.ReplyPostCommand) *model.Notification {
	return &model.Notification{
		RequestID:          requestID,
		TargetRealAliasIDs: command.TargetRealAliasIds,
		Type:               model.TypeClub,
		Subtype:            model.SubtypeReplyPost,
		ThumbnailURI:       command.ThumbnailUri,
		CreatedTime:        time.Now().UnixMilli(),
		Metadata: &model.ReplyPostMetadata{
			ClubID:            command.ClubId,
			ClubName:          command.ClubName,
			AuthorRealAliasID: command.AuthorRealAliasId,
			AuthorNickname:    command.AuthorNickname,
			PostID:            command.PostId,
			CommentID:         command.CommentId,
			IsOfficialClub:    command.IsOfficialClub,
		},
	}
}

func (c *ClubController) NotifyReplyComment(
	ctx context.Context, command *pb.ReplyCommentCommand,
) (*pb.ReplyCommentResult, error) {
	notification := makeReplyCommentNotification(c.idGenerator.Next(), command)
	requestID, err := c.produce(notification)
	if err != nil {
		return nil, errors.Wrap(err, "produce error")
	}

	return &pb.ReplyCommentResult{
		Id: requestID,
	}, nil
}

func makeReplyCommentNotification(
	requestID int64, command *pb.ReplyCommentCommand,
) *model.Notification {
	return &model.Notification{
		RequestID:          requestID,
		TargetRealAliasIDs: command.TargetRealAliasIds,
		Type:               model.TypeClub,
		Subtype:            model.SubtypeReplyComment,
		ThumbnailURI:       command.ThumbnailUri,
		CreatedTime:        time.Now().UnixMilli(),
		Metadata: &model.ReplyCommentMetadata{
			ClubID:            command.ClubId,
			ClubName:          command.ClubName,
			AuthorRealAliasID: command.AuthorRealAliasId,
			AuthorNickname:    command.AuthorNickname,
			PostID:            command.PostId,
			CommentID:         command.CommentId,
			ReplyID:           command.ReplyId,
			IsOfficialClub:    command.IsOfficialClub,
		},
	}
}

func (c *ClubController) NotifyTaggedComment(
	ctx context.Context, command *pb.TaggedCommentCommand,
) (*pb.TaggedCommentResult, error) {
	notification := makeTaggedCommentNotification(c.idGenerator.Next(), command)
	requestID, err := c.produce(notification)
	if err != nil {
		return nil, errors.Wrap(err, "produce error")
	}

	return &pb.TaggedCommentResult{
		Id: requestID,
	}, nil
}

func makeTaggedCommentNotification(
	requestID int64, command *pb.TaggedCommentCommand,
) *model.Notification {
	return &model.Notification{
		RequestID:          requestID,
		TargetRealAliasIDs: command.TargetRealAliasIds,
		Type:               model.TypeClub,
		Subtype:            model.SubtypeTaggedComment,
		ThumbnailURI:       command.ThumbnailUri,
		CreatedTime:        time.Now().UnixMilli(),
		Metadata: &model.TaggedCommentMetadata{
			ClubID:            command.ClubId,
			ClubName:          command.ClubName,
			AuthorRealAliasID: command.AuthorRealAliasId,
			AuthorNickname:    command.AuthorNickname,
			PostID:            command.PostId,
			CommentID:         command.CommentId,
			IsOfficialClub:    command.IsOfficialClub,
		},
	}
}

func (c *ClubController) NotifyApplicationAccepted(
	ctx context.Context, command *pb.ApplicationAcceptedCommand,
) (*pb.ApplicationAcceptedResult, error) {
	notification := makeApplicationAcceptedNotification(c.idGenerator.Next(), command)
	requestID, err := c.produce(notification)
	if err != nil {
		return nil, errors.Wrap(err, "produce error")
	}

	return &pb.ApplicationAcceptedResult{
		Id: requestID,
	}, nil
}

func makeApplicationAcceptedNotification(
	requestID int64,
	command *pb.ApplicationAcceptedCommand,
) *model.Notification {
	return &model.Notification{
		RequestID:          requestID,
		TargetRealAliasIDs: command.TargetRealAliasIds,
		Type:               model.TypeClub,
		Subtype:            model.SubtypeApplicationAccepted,
		ThumbnailURI:       command.ThumbnailUri,
		CreatedTime:        time.Now().UnixMilli(),
		Metadata: &model.ApplicationAcceptedMetadata{
			ClubID:         command.ClubId,
			ClubName:       command.ClubName,
			IsOfficialClub: command.IsOfficialClub,
		},
	}
}

func (c *ClubController) NotifyApplicationRequested(
	ctx context.Context, command *pb.ApplicationRequestedCommand,
) (*pb.ApplicationRequestedResult, error) {
	notification := makeApplicationRequestedNotification(c.idGenerator.Next(), command)
	requestID, err := c.produce(notification)
	if err != nil {
		return nil, errors.Wrap(err, "produce error")
	}

	return &pb.ApplicationRequestedResult{
		Id: requestID,
	}, nil
}

func makeApplicationRequestedNotification(
	requestID int64,
	command *pb.ApplicationRequestedCommand,
) *model.Notification {
	return &model.Notification{
		RequestID:          requestID,
		TargetRealAliasIDs: command.TargetRealAliasIds,
		Type:               model.TypeClub,
		Subtype:            model.SubtypeApplicationRequested,
		ThumbnailURI:       command.ThumbnailUri,
		CreatedTime:        time.Now().UnixMilli(),
		Metadata: &model.ApplicationRequestedMetadata{
			ClubID:         command.ClubId,
			ClubName:       command.ClubName,
			IsOfficialClub: command.IsOfficialClub,
		},
	}
}

func (c *ClubController) NotifyContentReported(
	ctx context.Context, command *pb.ContentReportedCommand,
) (*pb.ContentReportedResult, error) {
	notification := makeContentReportedNotification(c.idGenerator.Next(), command)
	requestID, err := c.produce(notification)
	if err != nil {
		return nil, errors.Wrap(err, "produce error")
	}

	return &pb.ContentReportedResult{
		Id: requestID,
	}, nil
}

func makeContentReportedNotification(
	requestID int64,
	command *pb.ContentReportedCommand,
) *model.Notification {
	return &model.Notification{
		RequestID:          requestID,
		TargetRealAliasIDs: command.TargetRealAliasIds,
		Type:               model.TypeClub,
		Subtype:            model.SubtypeContentReported,
		ThumbnailURI:       command.ThumbnailUri,
		CreatedTime:        time.Now().UnixMilli(),
		Metadata: &model.ContentReportedMetadata{
			ClubID:         command.ClubId,
			ClubName:       command.ClubName,
			IsOfficialClub: command.IsOfficialClub,
		},
	}
}

func (c *ClubController) NotifyClubRoleToModerator(
	ctx context.Context, command *pb.ClubRoleToModeratorCommand,
) (*pb.ClubRoleToModeratorResult, error) {
	notification := makeRoleToModeratorNotification(c.idGenerator.Next(), command)
	requestID, err := c.produce(notification)
	if err != nil {
		return nil, errors.Wrap(err, "produce error")
	}

	return &pb.ClubRoleToModeratorResult{
		Id: requestID,
	}, nil
}

func makeRoleToModeratorNotification(
	requestID int64,
	command *pb.ClubRoleToModeratorCommand,
) *model.Notification {
	return &model.Notification{
		RequestID:          requestID,
		TargetRealAliasIDs: command.TargetRealAliasIds,
		Type:               model.TypeClub,
		Subtype:            model.SubtypeRoleToModerator,
		ThumbnailURI:       command.ThumbnailUri,
		CreatedTime:        time.Now().UnixMilli(),
		Metadata: &model.ContentRoleToModeratorMetadata{
			ClubID:         command.ClubId,
			ClubName:       command.ClubName,
			IsOfficialClub: command.IsOfficialClub,
		},
	}
}

func (c *ClubController) NotifyPostDeletedByReport(
	ctx context.Context, command *pb.PostDeletedByReportCommand,
) (*pb.PostDeletedByReportResult, error) {
	notification := makePostDeletedByReportNotification(c.idGenerator.Next(), command)
	requestID, err := c.produce(notification)
	if err != nil {
		return nil, errors.Wrap(err, "produce error")
	}

	return &pb.PostDeletedByReportResult{
		Id: requestID,
	}, nil
}

func makePostDeletedByReportNotification(
	requestID int64,
	command *pb.PostDeletedByReportCommand,
) *model.Notification {
	return &model.Notification{
		RequestID:          requestID,
		TargetRealAliasIDs: command.TargetRealAliasIds,
		Type:               model.TypeClub,
		Subtype:            model.SubtypePostDeletedByReport,
		ThumbnailURI:       command.ThumbnailUri,
		CreatedTime:        time.Now().UnixMilli(),
		Metadata: &model.PostDeletedByReportMetadata{
			ClubID:         command.ClubId,
			ClubName:       command.ClubName,
			PostID:         command.PostId,
			ReportJudgeID:  command.ReportJudgeId,
			IsOfficialClub: command.IsOfficialClub,
		},
	}
}

func (c *ClubController) NotifyPostDeletedByModerator(
	ctx context.Context, command *pb.PostDeletedByModeratorCommand,
) (*pb.PostDeletedByModeratorResult, error) {
	notification := makePostDeletedByModeratorNotification(c.idGenerator.Next(), command)
	requestID, err := c.produce(notification)
	if err != nil {
		return nil, errors.Wrap(err, "produce error")
	}

	return &pb.PostDeletedByModeratorResult{
		Id: requestID,
	}, nil
}

func makePostDeletedByModeratorNotification(
	requestID int64,
	command *pb.PostDeletedByModeratorCommand,
) *model.Notification {
	return &model.Notification{
		RequestID:          requestID,
		TargetRealAliasIDs: command.TargetRealAliasIds,
		Type:               model.TypeClub,
		Subtype:            model.SubtypePostDeletedByModerator,
		ThumbnailURI:       command.ThumbnailUri,
		CreatedTime:        time.Now().UnixMilli(),
		Metadata: &model.PostDeletedByModeratorMetadata{
			ClubID:         command.ClubId,
			ClubName:       command.ClubName,
			PostID:         command.PostId,
			IsOfficialClub: command.IsOfficialClub,
		},
	}
}

func (c *ClubController) NotifyPostDeletedByAdmin(
	ctx context.Context, command *pb.PostDeletedByAdminCommand,
) (*pb.PostDeletedByAdminResult, error) {
	notification := makePostDeletedByAdminNotification(c.idGenerator.Next(), command)
	requestID, err := c.produce(notification)
	if err != nil {
		return nil, errors.Wrap(err, "produce error")
	}

	return &pb.PostDeletedByAdminResult{
		Id: requestID,
	}, nil
}

func makePostDeletedByAdminNotification(
	requestID int64,
	command *pb.PostDeletedByAdminCommand,
) *model.Notification {
	return &model.Notification{
		RequestID:          requestID,
		TargetRealAliasIDs: command.TargetRealAliasIds,
		Type:               model.TypeClub,
		Subtype:            model.SubtypePostDeletedByAdmin,
		ThumbnailURI:       command.ThumbnailUri,
		CreatedTime:        time.Now().UnixMilli(),
		Metadata: &model.PostDeletedByAdminMetadata{
			ClubID:         command.ClubId,
			ClubName:       command.ClubName,
			PostID:         command.PostId,
			IsOfficialClub: command.IsOfficialClub,
		},
	}
}

func (c *ClubController) NotifyPostDeletedByAdminForModerator(
	ctx context.Context, command *pb.PostDeletedByAdminForModeratorCommand,
) (*pb.PostDeletedByAdminForModeratorResult, error) {
	notification := makePostDeletedByAdminForModeratorNotification(
		c.idGenerator.Next(), command)
	requestID, err := c.produce(notification)
	if err != nil {
		return nil, errors.Wrap(err, "produce error")
	}

	return &pb.PostDeletedByAdminForModeratorResult{
		Id: requestID,
	}, nil
}

func makePostDeletedByAdminForModeratorNotification(
	requestID int64,
	command *pb.PostDeletedByAdminForModeratorCommand,
) *model.Notification {
	return &model.Notification{
		RequestID:          requestID,
		TargetRealAliasIDs: command.TargetRealAliasIds,
		Type:               model.TypeClub,
		Subtype:            model.SubtypePostDeletedByAdminForModerator,
		ThumbnailURI:       command.ThumbnailUri,
		CreatedTime:        time.Now().UnixMilli(),
		Metadata: &model.PostDeletedByAdminForModeratorMetadata{
			ClubID:         command.ClubId,
			ClubName:       command.ClubName,
			PostID:         command.PostId,
			Content:        command.Content,
			IsOfficialClub: command.IsOfficialClub,
		},
	}
}

func (c *ClubController) NotifyCommentDeletedByReport(
	ctx context.Context, command *pb.CommentDeletedByReportCommand,
) (*pb.CommentDeletedByReportResult, error) {
	notification := makeCommentDeletedByReportNotification(c.idGenerator.Next(), command)
	requestID, err := c.produce(notification)
	if err != nil {
		return nil, errors.Wrap(err, "produce error")
	}

	return &pb.CommentDeletedByReportResult{
		Id: requestID,
	}, nil
}

func makeCommentDeletedByReportNotification(
	requestID int64,
	command *pb.CommentDeletedByReportCommand,
) *model.Notification {
	return &model.Notification{
		RequestID:          requestID,
		TargetRealAliasIDs: command.TargetRealAliasIds,
		Type:               model.TypeClub,
		Subtype:            model.SubtypeCommentDeletedByReport,
		ThumbnailURI:       command.ThumbnailUri,
		CreatedTime:        time.Now().UnixMilli(),
		Metadata: &model.CommentDeletedByReportMetadata{
			ClubID:         command.ClubId,
			ClubName:       command.ClubName,
			CommentID:      command.CommentId,
			ReportJudgeID:  command.ReportJudgeId,
			IsOfficialClub: command.IsOfficialClub,
		},
	}
}

func (c *ClubController) NotifyCommentDeletedByModerator(
	ctx context.Context, command *pb.CommentDeletedByModeratorCommand,
) (*pb.CommentDeletedByModeratorResult, error) {
	notification := makeCommentDeletedByModeratorNotification(c.idGenerator.Next(), command)
	requestID, err := c.produce(notification)
	if err != nil {
		return nil, errors.Wrap(err, "produce error")
	}

	return &pb.CommentDeletedByModeratorResult{
		Id: requestID,
	}, nil
}

func makeCommentDeletedByModeratorNotification(
	requestID int64,
	command *pb.CommentDeletedByModeratorCommand,
) *model.Notification {
	return &model.Notification{
		RequestID:          requestID,
		TargetRealAliasIDs: command.TargetRealAliasIds,
		Type:               model.TypeClub,
		Subtype:            model.SubtypeCommentDeletedByModerator,
		ThumbnailURI:       command.ThumbnailUri,
		CreatedTime:        time.Now().UnixMilli(),
		Metadata: &model.CommentDeletedByModeratorMetadata{
			ClubID:         command.ClubId,
			ClubName:       command.ClubName,
			CommentID:      command.CommentId,
			IsOfficialClub: command.IsOfficialClub,
		},
	}
}

func (c *ClubController) NotifyCommentDeletedByAdmin(
	ctx context.Context, command *pb.CommentDeletedByAdminCommand,
) (*pb.CommentDeletedByAdminResult, error) {
	notification := makeCommentDeletedByAdminNotification(c.idGenerator.Next(), command)
	requestID, err := c.produce(notification)
	if err != nil {
		return nil, errors.Wrap(err, "produce error")
	}

	return &pb.CommentDeletedByAdminResult{
		Id: requestID,
	}, nil
}

func makeCommentDeletedByAdminNotification(
	requestID int64,
	command *pb.CommentDeletedByAdminCommand,
) *model.Notification {
	return &model.Notification{
		RequestID:          requestID,
		TargetRealAliasIDs: command.TargetRealAliasIds,
		Type:               model.TypeClub,
		Subtype:            model.SubtypeCommentDeletedByAdmin,
		ThumbnailURI:       command.ThumbnailUri,
		CreatedTime:        time.Now().UnixMilli(),
		Metadata: &model.CommentDeletedByAdminMetadata{
			ClubID:         command.ClubId,
			ClubName:       command.ClubName,
			CommentID:      command.CommentId,
			IsOfficialClub: command.IsOfficialClub,
		},
	}
}

func (c *ClubController) NotifyCommentDeletedByAdminForModerator(
	ctx context.Context, command *pb.CommentDeletedByAdminForModeratorCommand,
) (*pb.CommentDeletedByAdminForModeratorResult, error) {
	notification := makeCommentDeletedByAdminForModeratorNotification(
		c.idGenerator.Next(), command)
	requestID, err := c.produce(notification)
	if err != nil {
		return nil, errors.Wrap(err, "produce error")
	}

	return &pb.CommentDeletedByAdminForModeratorResult{
		Id: requestID,
	}, nil
}

func makeCommentDeletedByAdminForModeratorNotification(
	requestID int64,
	command *pb.CommentDeletedByAdminForModeratorCommand,
) *model.Notification {
	return &model.Notification{
		RequestID:          requestID,
		TargetRealAliasIDs: command.TargetRealAliasIds,
		Type:               model.TypeClub,
		Subtype:            model.SubtypeCommentDeletedByAdminForModerator,
		ThumbnailURI:       command.ThumbnailUri,
		CreatedTime:        time.Now().UnixMilli(),
		Metadata: &model.CommentDeletedByAdminForModeratorMetadata{
			ClubID:         command.ClubId,
			ClubName:       command.ClubName,
			CommentID:      command.CommentId,
			Content:        command.Content,
			IsOfficialClub: command.IsOfficialClub,
		},
	}
}

func (c *ClubController) NotifyReplyDeletedByReport(
	ctx context.Context, command *pb.ReplyDeletedByReportCommand,
) (*pb.ReplyDeletedByReportResult, error) {
	notification := makeReplyDeletedByReportNotification(c.idGenerator.Next(), command)
	requestID, err := c.produce(notification)
	if err != nil {
		return nil, errors.Wrap(err, "produce error")
	}

	return &pb.ReplyDeletedByReportResult{
		Id: requestID,
	}, nil
}

func makeReplyDeletedByReportNotification(
	requestID int64,
	command *pb.ReplyDeletedByReportCommand,
) *model.Notification {
	return &model.Notification{
		RequestID:          requestID,
		TargetRealAliasIDs: command.TargetRealAliasIds,
		Type:               model.TypeClub,
		Subtype:            model.SubtypeReplyDeletedByReport,
		ThumbnailURI:       command.ThumbnailUri,
		CreatedTime:        time.Now().UnixMilli(),
		Metadata: &model.ReplyDeletedByReportMetadata{
			ClubID:         command.ClubId,
			ClubName:       command.ClubName,
			ReplyID:        command.ReplyId,
			ReportJudgeID:  command.ReportJudgeId,
			IsOfficialClub: command.IsOfficialClub,
		},
	}
}

func (c *ClubController) NotifyReplyDeletedByModerator(
	ctx context.Context, command *pb.ReplyDeletedByModeratorCommand,
) (*pb.ReplyDeletedByModeratorResult, error) {
	notification := makeReplyDeletedByModeratorNotification(c.idGenerator.Next(), command)
	requestID, err := c.produce(notification)
	if err != nil {
		return nil, errors.Wrap(err, "produce error")
	}

	return &pb.ReplyDeletedByModeratorResult{
		Id: requestID,
	}, nil
}

func makeReplyDeletedByModeratorNotification(
	requestID int64,
	command *pb.ReplyDeletedByModeratorCommand,
) *model.Notification {
	return &model.Notification{
		RequestID:          requestID,
		TargetRealAliasIDs: command.TargetRealAliasIds,
		Type:               model.TypeClub,
		Subtype:            model.SubtypeReplyDeletedByModerator,
		ThumbnailURI:       command.ThumbnailUri,
		CreatedTime:        time.Now().UnixMilli(),
		Metadata: &model.ReplyDeletedByModeratorMetadata{
			ClubID:         command.ClubId,
			ClubName:       command.ClubName,
			ReplyID:        command.ReplyId,
			IsOfficialClub: command.IsOfficialClub,
		},
	}
}

func (c *ClubController) NotifyReplyDeletedByAdmin(
	ctx context.Context, command *pb.ReplyDeletedByAdminCommand,
) (*pb.ReplyDeletedByAdminResult, error) {
	notification := makeReplyDeletedByAdminNotification(c.idGenerator.Next(), command)
	requestID, err := c.produce(notification)
	if err != nil {
		return nil, errors.Wrap(err, "produce error")
	}

	return &pb.ReplyDeletedByAdminResult{
		Id: requestID,
	}, nil
}

func makeReplyDeletedByAdminNotification(
	requestID int64,
	command *pb.ReplyDeletedByAdminCommand,
) *model.Notification {
	return &model.Notification{
		RequestID:          requestID,
		TargetRealAliasIDs: command.TargetRealAliasIds,
		Type:               model.TypeClub,
		Subtype:            model.SubtypeReplyDeletedByAdmin,
		ThumbnailURI:       command.ThumbnailUri,
		CreatedTime:        time.Now().UnixMilli(),
		Metadata: &model.ReplyDeletedByAdminMetadata{
			ClubID:         command.ClubId,
			ClubName:       command.ClubName,
			ReplyID:        command.ReplyId,
			IsOfficialClub: command.IsOfficialClub,
		},
	}
}

func (c *ClubController) NotifyReplyDeletedByAdminForModerator(
	ctx context.Context, command *pb.ReplyDeletedByAdminForModeratorCommand,
) (*pb.ReplyDeletedByAdminForModeratorResult, error) {
	notification := makeReplyDeletedByAdminForModeratorNotification(
		c.idGenerator.Next(), command)
	requestID, err := c.produce(notification)
	if err != nil {
		return nil, errors.Wrap(err, "produce error")
	}

	return &pb.ReplyDeletedByAdminForModeratorResult{
		Id: requestID,
	}, nil
}

func makeReplyDeletedByAdminForModeratorNotification(
	requestID int64,
	command *pb.ReplyDeletedByAdminForModeratorCommand,
) *model.Notification {
	return &model.Notification{
		RequestID:          requestID,
		TargetRealAliasIDs: command.TargetRealAliasIds,
		Type:               model.TypeClub,
		Subtype:            model.SubtypeReplyDeletedByAdminForModerator,
		ThumbnailURI:       command.ThumbnailUri,
		CreatedTime:        time.Now().UnixMilli(),
		Metadata: &model.ReplyDeletedByAdminForModeratorMetadata{
			ClubID:         command.ClubId,
			ClubName:       command.ClubName,
			ReplyID:        command.ReplyId,
			Content:        command.Content,
			IsOfficialClub: command.IsOfficialClub,
		},
	}
}

func (c *ClubController) produce(notification *model.Notification) (int64, error) {
	kafkaEvent := &model.KafkaEvent{Data: notification, Type: model.KafkaEventTypeNewMessage}
	err := c.producer.Produce(kafkaEvent)
	if err != nil {
		c.logger.Errorf("unable to produce notification %d to worker, error: %s",
			notification.RequestID, err)
		return 0, errors.Wrap(err, "produce error")
	}
	return notification.RequestID, nil
}
