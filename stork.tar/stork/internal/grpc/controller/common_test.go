package controller

import (
	"context"
	"fmt"
	"testing"
	"time"

	"beango.visualstudio.com/BeanGoAPP/caerus/database"
	pb "beango.visualstudio.com/BeanGoAPP/stork/internal/gen/pb/notification"
	lastresendcache "beango.visualstudio.com/BeanGoAPP/stork/internal/grpc/controller/last_resend_cache"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/kafka"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/repository"
	"github.com/golang/mock/gomock"
	"github.com/sirupsen/logrus"
	"github.com/stretchr/testify/require"
)

func TestResendnotification(t *testing.T) {
	realAliasID := int64(123)
	lastID := int64(0)
	notification := &model.Notification{}
	notifications := make([]*model.Notification, 0, 10)
	for i := 0; i < 10; i++ {
		notifications = append(notifications, notification)
	}
	kafkaEvent := &model.KafkaEvent{
		Data: notification,
		Type: model.KafkaEventResend,
	}
	ctx := initReadContext(t)
	controller, repo, producer, lastResendCache := newCommonControllerAndMocks(t)
	lastResendCache.EXPECT().GetID(realAliasID).Return(int64(999999), nil)
	lastResendCache.EXPECT().SetID(realAliasID, lastID).Return(nil)
	repo.EXPECT().Find(
		gomock.Any(), realAliasID, lastID,
		gomock.Any(), 1000,
	).Return(notifications, nil)
	producer.EXPECT().Produce(kafkaEvent).Times(10).Return(nil)

	command := &pb.ResendNotificationCommand{
		RealAliasId: realAliasID,
		LastId:      lastID,
	}
	_, err := controller.ResendNotifications(ctx, command)
	require.NoError(t, err)
}

func TestResendnotification_InCache(t *testing.T) {
	realAliasID := int64(123)
	lastID := int64(0)
	ctx := initReadContext(t)
	controller, _, _, lastResendCache := newCommonControllerAndMocks(t)
	lastResendCache.EXPECT().GetID(realAliasID).Return(lastID, nil)

	command := &pb.ResendNotificationCommand{
		RealAliasId: realAliasID,
		LastId:      lastID,
	}
	_, err := controller.ResendNotifications(ctx, command)
	require.NoError(t, err)
}

func TestResendnotification_CacheError(t *testing.T) {
	realAliasID := int64(123)
	lastID := int64(0)
	ctx := initReadContext(t)
	controller, repo, producer, lastResendCache := newCommonControllerAndMocks(t)
	lastResendCache.EXPECT().GetID(realAliasID).Return(int64(0), fmt.Errorf("err"))
	lastResendCache.EXPECT().SetID(realAliasID, lastID).Return(nil)
	notification := &model.Notification{}
	notifications := make([]*model.Notification, 0, 10)
	for i := 0; i < 10; i++ {
		notifications = append(notifications, notification)
	}
	kafkaEvent := &model.KafkaEvent{
		Data: notification,
		Type: model.KafkaEventResend,
	}
	repo.EXPECT().Find(
		gomock.Any(), realAliasID, lastID,
		gomock.Any(), 1000,
	).Return(notifications, nil)
	producer.EXPECT().Produce(kafkaEvent).Times(10).Return(nil)

	command := &pb.ResendNotificationCommand{
		RealAliasId: realAliasID,
		LastId:      lastID,
	}
	_, err := controller.ResendNotifications(ctx, command)
	require.NoError(t, err)
}

func TestResendnotification_Error(t *testing.T) {
	t.Run("noNotifications", testResendnotification_NoNotifications)
	t.Run("findError", testResendnotification_FindError)
	t.Run("produceError", testResendnotification_ProduceError)
	t.Run("noDBConn", testResendnotification_NoDBConnError)
}

func testResendnotification_NoNotifications(t *testing.T) {
	realAliasID := int64(123)
	lastID := int64(0)

	ctx := initReadContext(t)
	controller, repo, _, lastResendCache := newCommonControllerAndMocks(t)
	lastResendCache.EXPECT().GetID(realAliasID).Return(int64(999999), nil)
	lastResendCache.EXPECT().SetID(realAliasID, lastID).Return(nil)
	repo.EXPECT().Find(
		gomock.Any(), realAliasID, lastID,
		gomock.Any(), 1000,
	).Return([]*model.Notification{}, nil)

	command := &pb.ResendNotificationCommand{
		RealAliasId: realAliasID,
		LastId:      lastID,
	}
	_, err := controller.ResendNotifications(ctx, command)
	require.NoError(t, err)
}

func testResendnotification_FindError(t *testing.T) {
	realAliasID := int64(123)
	lastID := int64(0)

	ctx := initReadContext(t)
	controller, repo, _, lastResendCache := newCommonControllerAndMocks(t)
	lastResendCache.EXPECT().GetID(realAliasID).Return(int64(999999), nil)
	repo.EXPECT().Find(
		gomock.Any(), realAliasID, lastID,
		gomock.Any(), 1000,
	).Return(nil, fmt.Errorf("err"))

	command := &pb.ResendNotificationCommand{
		RealAliasId: realAliasID,
		LastId:      lastID,
	}
	_, err := controller.ResendNotifications(ctx, command)
	require.Error(t, err)
}

func testResendnotification_ProduceError(t *testing.T) {
	realAliasID := int64(123)
	lastID := int64(0)
	notification := &model.Notification{}
	notifications := make([]*model.Notification, 0, 10)
	for i := 0; i < 10; i++ {
		notifications = append(notifications, notification)
	}
	kafkaEvent := &model.KafkaEvent{
		Data: notification,
		Type: model.KafkaEventResend,
	}
	ctx := initReadContext(t)
	controller, repo, producer, lastResendCache := newCommonControllerAndMocks(t)
	lastResendCache.EXPECT().GetID(realAliasID).Return(int64(999999), nil)
	lastResendCache.EXPECT().SetID(realAliasID, lastID).Return(nil)
	repo.EXPECT().Find(
		gomock.Any(), realAliasID, lastID,
		gomock.Any(), 1000,
	).Return(notifications, nil)
	producer.EXPECT().Produce(kafkaEvent).Times(10).Return(fmt.Errorf("err"))

	command := &pb.ResendNotificationCommand{
		RealAliasId: realAliasID,
		LastId:      lastID,
	}
	_, err := controller.ResendNotifications(ctx, command)
	require.NoError(t, err)
}

func testResendnotification_NoDBConnError(t *testing.T) {
	realAliasID := int64(123)
	lastID := int64(0)

	controller, _, _, lastResendCache := newCommonControllerAndMocks(t)
	lastResendCache.EXPECT().GetID(realAliasID).Return(int64(999999), nil)

	command := &pb.ResendNotificationCommand{
		RealAliasId: realAliasID,
		LastId:      lastID,
	}
	_, err := controller.ResendNotifications(context.Background(), command)
	require.Error(t, err)
}

func newCommonControllerAndMocks(
	t *testing.T,
) (
	*CommonController, *repository.MockNotificationRepo,
	*kafka.MockNotificationProducer, *lastresendcache.MockLastResendCache,
) {
	ctrl := gomock.NewController(t)
	repo := repository.NewMockNotificationRepo(ctrl)
	producer := kafka.NewMockNotificationProducer(ctrl)
	resendcache := lastresendcache.NewMockLastResendCache(ctrl)

	controller := NewCommonController(repo, producer, time.Now(), 1000, resendcache, logrus.New())
	return controller, repo, producer, resendcache
}

func initReadContext(t *testing.T) context.Context {
	ctrl := gomock.NewController(t)
	conn := database.NewMockConnection(ctrl)
	return context.WithValue(context.Background(), "read_conn", conn) // nolint: staticcheck
}
