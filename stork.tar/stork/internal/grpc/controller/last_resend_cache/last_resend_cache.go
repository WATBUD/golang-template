package lastresendcache

import (
	"fmt"
	"strconv"
	"time"

	"beango.visualstudio.com/BeanGoAPP/caerus/redis"
)

func NewLastResendCache(redis redis.Redis) LastResendCache {
	return &lastResendCache{
		redis: redis,
	}
}

type LastResendCache interface {
	GetID(realAliasID int64) (int64, error)
	SetID(realAliasID int64, lastID int64) error
}

type lastResendCache struct {
	redis redis.Redis
}

func (l *lastResendCache) GetID(realAliasID int64) (int64, error) {
	key := l.getKey(realAliasID)
	value, err := l.redis.Get(key)
	if err != nil {
		return 0, fmt.Errorf("get %s error: %w", key, err)
	}

	if value == "" {
		return -1, nil
	}

	lastID, err := strconv.ParseInt(value, 10, 64)
	if err != nil {
		return 0, fmt.Errorf("parse %s error: %w", value, err)
	}
	return lastID, nil
}

func (l *lastResendCache) SetID(realAliasID int64, lastID int64) error {
	key := l.getKey(realAliasID)
	value := fmt.Sprintf("%d", lastID)
	err := l.redis.Set(key, value, 5*time.Minute)
	if err != nil {
		return fmt.Errorf("set %s error: %w", key, err)
	}
	return nil
}

func (l *lastResendCache) getKey(realAliasID int64) string {
	return fmt.Sprintf("stork:last_notification:%d", realAliasID)
}
