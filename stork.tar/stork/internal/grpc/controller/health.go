package controller

import (
	"context"

	"beango.visualstudio.com/BeanGoAPP/caerus/database"
	pb "beango.visualstudio.com/BeanGoAPP/stork/internal/gen/pb/health"
	"github.com/sirupsen/logrus"
)

func NewHealthController(
	db database.Database, logger logrus.FieldLogger,
) *HealthController {
	return &HealthController{db: db, logger: logger}
}

type HealthController struct {
	db     database.Database
	logger logrus.FieldLogger

	pb.UnimplementedHealthServer
}

func (c *HealthController) Check(
	ctx context.Context, input *pb.HealthCheckRequest,
) (*pb.HealthCheckResponse, error) {
	if err := c.db.Ping(); err != nil {
		c.logger.Errorf("database not available: %s", err)
		return &pb.HealthCheckResponse{
			Status: pb.HealthCheckResponse_NOT_SERVING}, nil
	}

	return &pb.HealthCheckResponse{
		Status: pb.HealthCheckResponse_SERVING}, nil
}
