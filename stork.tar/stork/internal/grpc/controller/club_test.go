package controller

import (
	"context"
	"testing"

	"beango.visualstudio.com/BeanGoAPP/caerus/snowflake"
	pb "beango.visualstudio.com/BeanGoAPP/stork/internal/gen/pb/notification"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/kafka"
	"github.com/golang/mock/gomock"
	"github.com/sirupsen/logrus"
	"github.com/stretchr/testify/require"
)

func TestNotifyNewPost(t *testing.T) {
	command := &pb.NewPostCommand{
		TargetRealAliasIds: []int64{1},
		ThumbnailUri:       "thumbnail",
		ClubId:             111,
		ClubName:           "club",
		AuthorRealAliasId:  222,
		AuthorNickname:     "author",
		PostId:             333,
		IsOfficialClub:     true,
		Content:            "xxxx",
	}

	controller, producer, generator := newControllerAndMocks(t)
	generator.EXPECT().Next().Return(int64(12345))
	producer.EXPECT().Produce(gomock.Any()).Return(nil)

	ctx := initContext(t)
	result, err := controller.NotifyNewPost(ctx, command)
	require.NoError(t, err)
	require.NotNil(t, result.GetId())
}

func TestNotifyReplyPost(t *testing.T) {
	command := &pb.ReplyPostCommand{
		TargetRealAliasIds: []int64{1},
		ThumbnailUri:       "thumbnail",
		ClubId:             111,
		ClubName:           "club",
		AuthorRealAliasId:  222,
		AuthorNickname:     "author",
		PostId:             333,
		IsOfficialClub:     true,
	}

	controller, producer, generator := newControllerAndMocks(t)
	generator.EXPECT().Next().Return(int64(12345))
	producer.EXPECT().Produce(gomock.Any()).Return(nil)

	ctx := initContext(t)
	result, err := controller.NotifyReplyPost(ctx, command)
	require.NoError(t, err)
	require.NotNil(t, result.GetId())
}

func TestNotifyReplyComment(t *testing.T) {
	command := &pb.ReplyCommentCommand{
		TargetRealAliasIds: []int64{1},
		ThumbnailUri:       "thumbnail",
		ClubId:             111,
		ClubName:           "club",
		AuthorRealAliasId:  222,
		AuthorNickname:     "author",
		PostId:             333,
		IsOfficialClub:     true,
		CommentId:          "444",
		ReplyId:            "555",
	}

	controller, producer, generator := newControllerAndMocks(t)
	generator.EXPECT().Next().Return(int64(12345))
	producer.EXPECT().Produce(gomock.Any()).Return(nil)

	ctx := initContext(t)
	result, err := controller.NotifyReplyComment(ctx, command)
	require.NoError(t, err)
	require.NotNil(t, result.GetId())
}

func TestNotifyTaggedComment(t *testing.T) {
	command := &pb.TaggedCommentCommand{
		TargetRealAliasIds: []int64{1},
		ThumbnailUri:       "thumbnail",
		ClubId:             111,
		ClubName:           "club",
		AuthorRealAliasId:  222,
		AuthorNickname:     "author",
		PostId:             333,
		IsOfficialClub:     true,
		CommentId:          "444",
	}

	controller, producer, generator := newControllerAndMocks(t)
	generator.EXPECT().Next().Return(int64(12345))
	producer.EXPECT().Produce(gomock.Any()).Return(nil)

	ctx := initContext(t)
	result, err := controller.NotifyTaggedComment(ctx, command)
	require.NoError(t, err)
	require.NotNil(t, result.GetId())
}

func TestNotifyApplicationAccepted(t *testing.T) {
	command := &pb.ApplicationAcceptedCommand{
		TargetRealAliasIds: []int64{1},
		ThumbnailUri:       "thumbnail",
		ClubId:             111,
		ClubName:           "club",
		IsOfficialClub:     true,
	}

	controller, producer, generator := newControllerAndMocks(t)
	generator.EXPECT().Next().Return(int64(12345))
	producer.EXPECT().Produce(gomock.Any()).Return(nil)

	ctx := initContext(t)
	result, err := controller.NotifyApplicationAccepted(ctx, command)
	require.NoError(t, err)
	require.NotNil(t, result.GetId())
}

func TestNotifyApplicationRequested(t *testing.T) {
	command := &pb.ApplicationRequestedCommand{
		TargetRealAliasIds: []int64{1},
		ThumbnailUri:       "thumbnail",
		ClubId:             111,
		ClubName:           "club",
		IsOfficialClub:     true,
	}

	controller, producer, generator := newControllerAndMocks(t)
	generator.EXPECT().Next().Return(int64(12345))
	producer.EXPECT().Produce(gomock.Any()).Return(nil)

	ctx := initContext(t)
	result, err := controller.NotifyApplicationRequested(ctx, command)
	require.NoError(t, err)
	require.NotNil(t, result.GetId())
}

func TestNotifyContentReported(t *testing.T) {
	command := &pb.ContentReportedCommand{
		TargetRealAliasIds: []int64{1},
		ThumbnailUri:       "thumbnail",
		ClubId:             111,
		ClubName:           "club",
		IsOfficialClub:     true,
	}

	controller, producer, generator := newControllerAndMocks(t)
	generator.EXPECT().Next().Return(int64(12345))
	producer.EXPECT().Produce(gomock.Any()).Return(nil)

	ctx := initContext(t)
	result, err := controller.NotifyContentReported(ctx, command)
	require.NoError(t, err)
	require.NotNil(t, result.GetId())
}

func TestNotifyRoleToModerator(t *testing.T) {
	command := &pb.ClubRoleToModeratorCommand{
		TargetRealAliasIds: []int64{1},
		ThumbnailUri:       "thumbnail",
		ClubId:             111,
		ClubName:           "club",
		IsOfficialClub:     true,
	}

	controller, producer, generator := newControllerAndMocks(t)
	generator.EXPECT().Next().Return(int64(12345))
	producer.EXPECT().Produce(gomock.Any()).Return(nil)

	ctx := initContext(t)
	result, err := controller.NotifyClubRoleToModerator(ctx, command)
	require.NoError(t, err)
	require.NotNil(t, result.GetId())
}

func TestNotifyPostDeletedByReport(t *testing.T) {
	command := &pb.PostDeletedByReportCommand{
		TargetRealAliasIds: []int64{1},
		ThumbnailUri:       "thumbnail",
		ClubId:             111,
		ClubName:           "club",
		PostId:             222,
		ReportJudgeId:      333,
		IsOfficialClub:     true,
	}

	controller, producer, generator := newControllerAndMocks(t)
	generator.EXPECT().Next().Return(int64(12345))
	producer.EXPECT().Produce(gomock.Any()).Return(nil)

	ctx := initContext(t)
	result, err := controller.NotifyPostDeletedByReport(ctx, command)
	require.NoError(t, err)
	require.NotNil(t, result.GetId())
}

func TestNotifyPostDeletedByModerator(t *testing.T) {
	command := &pb.PostDeletedByModeratorCommand{
		TargetRealAliasIds: []int64{1},
		ThumbnailUri:       "thumbnail",
		ClubId:             111,
		ClubName:           "club",
		PostId:             222,
		IsOfficialClub:     true,
	}

	controller, producer, generator := newControllerAndMocks(t)
	generator.EXPECT().Next().Return(int64(12345))
	producer.EXPECT().Produce(gomock.Any()).Return(nil)

	ctx := initContext(t)
	result, err := controller.NotifyPostDeletedByModerator(ctx, command)
	require.NoError(t, err)
	require.NotNil(t, result.GetId())
}

func TestNotifyCommentDeletedByReport(t *testing.T) {
	command := &pb.CommentDeletedByReportCommand{
		TargetRealAliasIds: []int64{1},
		ThumbnailUri:       "thumbnail",
		ClubId:             111,
		ClubName:           "club",
		CommentId:          "222",
		ReportJudgeId:      333,
		IsOfficialClub:     true,
	}

	controller, producer, generator := newControllerAndMocks(t)
	generator.EXPECT().Next().Return(int64(12345))
	producer.EXPECT().Produce(gomock.Any()).Return(nil)

	ctx := initContext(t)
	result, err := controller.NotifyCommentDeletedByReport(ctx, command)
	require.NoError(t, err)
	require.NotNil(t, result.GetId())
}

func TestNotifyCommentDeletedByModerator(t *testing.T) {
	command := &pb.CommentDeletedByModeratorCommand{
		TargetRealAliasIds: []int64{1},
		ThumbnailUri:       "thumbnail",
		ClubId:             111,
		ClubName:           "club",
		CommentId:          "222",
		IsOfficialClub:     true,
	}

	controller, producer, generator := newControllerAndMocks(t)
	generator.EXPECT().Next().Return(int64(12345))
	producer.EXPECT().Produce(gomock.Any()).Return(nil)

	ctx := initContext(t)
	result, err := controller.NotifyCommentDeletedByModerator(ctx, command)
	require.NoError(t, err)
	require.NotNil(t, result.GetId())
}

func TestNotifyReplyDeletedByReport(t *testing.T) {
	command := &pb.ReplyDeletedByReportCommand{
		TargetRealAliasIds: []int64{1},
		ThumbnailUri:       "thumbnail",
		ClubId:             111,
		ClubName:           "club",
		ReplyId:            "222",
		ReportJudgeId:      333,
		IsOfficialClub:     true,
	}

	controller, producer, generator := newControllerAndMocks(t)
	generator.EXPECT().Next().Return(int64(12345))
	producer.EXPECT().Produce(gomock.Any()).Return(nil)

	ctx := initContext(t)
	result, err := controller.NotifyReplyDeletedByReport(ctx, command)
	require.NoError(t, err)
	require.NotNil(t, result.GetId())
}

func TestNotifyReplyDeletedByModerator(t *testing.T) {
	command := &pb.ReplyDeletedByModeratorCommand{
		TargetRealAliasIds: []int64{1},
		ThumbnailUri:       "thumbnail",
		ClubId:             111,
		ClubName:           "club",
		ReplyId:            "222",
		IsOfficialClub:     true,
	}

	controller, producer, generator := newControllerAndMocks(t)
	generator.EXPECT().Next().Return(int64(12345))
	producer.EXPECT().Produce(gomock.Any()).Return(nil)

	ctx := initContext(t)
	result, err := controller.NotifyReplyDeletedByModerator(ctx, command)
	require.NoError(t, err)
	require.NotNil(t, result.GetId())
}

func newControllerAndMocks(
	t *testing.T,
) (
	*ClubController, *kafka.MockNotificationProducer,
	*snowflake.MockGenerator,
) {
	ctrl := gomock.NewController(t)
	producer := kafka.NewMockNotificationProducer(ctrl)
	generator := snowflake.NewMockGenerator(ctrl)

	controller := NewClubController(producer, generator, logrus.New())
	return controller, producer, generator
}

func initContext(t *testing.T) context.Context {
	return context.Background() // nolint: staticcheck
}
