package messagebuilderfactory

import (
	"testing"

	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"github.com/golang/mock/gomock"
	"github.com/sirupsen/logrus"
	"github.com/stretchr/testify/require"
)

func TestMakeBuilder(t *testing.T) {
	ctrl := gomock.NewController(t)
	mockedBuilder := NewMockMessageBuilder(ctrl)
	mockedBuilder.EXPECT().GetType().Return("foo")
	mockedBuilder.EXPECT().GetSubtype().Return("bar")

	n := &model.Notification{
		Type:    "foo",
		Subtype: "bar",
	}
	factory, err := NewMessageBuilderFactory(
		[]MessageBuilder{mockedBuilder}, logrus.New(),
	)
	require.NoError(t, err)

	builder, err := factory.Make(n)
	require.NoError(t, err)
	require.Equal(t, mockedBuilder, builder)
}

func TestMakeBuilderFail(t *testing.T) {
	t.Run("NotExist", testMakeBuilder_NotExist)
	t.Run("ConflictBuilder", testMakeBuilder_ConflictBuilder)
}

func testMakeBuilder_NotExist(t *testing.T) {
	ctrl := gomock.NewController(t)
	mockedBuilder := NewMockMessageBuilder(ctrl)
	mockedBuilder.EXPECT().GetType().Return("foo")
	mockedBuilder.EXPECT().GetSubtype().Return("bar")

	n := &model.Notification{
		Type:    "not",
		Subtype: "exist",
	}
	factory, err := NewMessageBuilderFactory(
		[]MessageBuilder{mockedBuilder}, logrus.New(),
	)
	require.NoError(t, err)

	builder, err := factory.Make(n)
	require.Error(t, err)
	require.Nil(t, builder)
}

func testMakeBuilder_ConflictBuilder(t *testing.T) {
	ctrl := gomock.NewController(t)
	mockedBuilder := NewMockMessageBuilder(ctrl)
	mockedBuilder.EXPECT().GetType().Return("foo").Times(2)
	mockedBuilder.EXPECT().GetSubtype().Return("bar").Times(2)

	factory, err := NewMessageBuilderFactory(
		[]MessageBuilder{mockedBuilder, mockedBuilder}, logrus.New(),
	)
	require.Error(t, err)
	require.Nil(t, factory)
}
