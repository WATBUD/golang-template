package club

import (
	pb "beango.visualstudio.com/BeanGoAPP/stork/internal/gen/pb/notification"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/worker/message_builder_factory/builder"
	"github.com/pkg/errors"
	"google.golang.org/protobuf/proto"
)

func init() {
	messageBuilder := &postDeletedByReportMessageBuilder{}
	builder.AllBuilders = append(
		builder.AllBuilders, messageBuilder)
}

type postDeletedByReportMessageBuilder struct {
}

func (b *postDeletedByReportMessageBuilder) GetType() string {
	return model.TypeClub
}

func (b *postDeletedByReportMessageBuilder) GetSubtype() string {
	return model.SubtypePostDeletedByReport
}

func (b *postDeletedByReportMessageBuilder) Build(
	notification *model.Notification,
) (proto.Message, error) {
	metadata := model.PostDeletedByReportMetadata{}
	err := builder.MarshalMetadata(notification.Metadata, &metadata)
	if err != nil {
		return nil, errors.Wrap(err, "convert metadata error")
	}

	return &pb.Notification{
		Id:           notification.RequestID,
		Type:         pb.NotificationType_TypeClub,
		SubType:      pb.NotificationSubtype_SubtypePostDeletedByReport,
		ThumbnailUri: notification.ThumbnailURI,
		CreatedTime:  notification.CreatedTime,
		Metadata: &pb.NotificationMetadata{
			MetadataOneof: &pb.NotificationMetadata_PostDeletedByReport{
				PostDeletedByReport: &pb.PostDeletedByReportMetadata{
					ClubId:         metadata.ClubID,
					ClubName:       metadata.ClubName,
					IsOfficialClub: metadata.IsOfficialClub,
				},
			},
		},
	}, nil
}
