package club

import (
	"testing"

	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"github.com/stretchr/testify/require"
)

func TestReplyPostGetType(t *testing.T) {
	builder := replyPostMessageBuilder{}
	require.Equal(t, model.TypeClub, builder.GetType())
}

func TestReplyPostGetSubtype(t *testing.T) {
	builder := replyPostMessageBuilder{}
	require.Equal(
		t, model.SubtypeReplyPost, builder.GetSubtype())
}
