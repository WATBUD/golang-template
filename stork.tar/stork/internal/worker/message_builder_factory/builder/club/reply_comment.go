package club

import (
	pb "beango.visualstudio.com/BeanGoAPP/stork/internal/gen/pb/notification"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/worker/message_builder_factory/builder"
	"github.com/pkg/errors"
	"google.golang.org/protobuf/proto"
)

func init() {
	messageBuilder := &replyCommentMessageBuilder{}
	builder.AllBuilders = append(
		builder.AllBuilders, messageBuilder)
}

type replyCommentMessageBuilder struct {
}

func (b *replyCommentMessageBuilder) GetType() string {
	return model.TypeClub
}

func (b *replyCommentMessageBuilder) GetSubtype() string {
	return model.SubtypeReplyComment
}

func (b *replyCommentMessageBuilder) Build(
	notification *model.Notification,
) (proto.Message, error) {
	metadata := model.ReplyCommentMetadata{}
	err := builder.MarshalMetadata(notification.Metadata, &metadata)
	if err != nil {
		return nil, errors.Wrap(err, "convert metadata error")
	}

	return &pb.Notification{
		Id:           notification.RequestID,
		Type:         pb.NotificationType_TypeClub,
		SubType:      pb.NotificationSubtype_SubtypeReplyComment,
		ThumbnailUri: notification.ThumbnailURI,
		CreatedTime:  notification.CreatedTime,
		Metadata: &pb.NotificationMetadata{
			MetadataOneof: &pb.NotificationMetadata_ClubReplyComment{
				ClubReplyComment: &pb.ClubReplyCommentMetadata{
					ClubId:            metadata.ClubID,
					ClubName:          metadata.ClubName,
					AuthorRealAliasId: metadata.AuthorRealAliasID,
					AuthorNickname:    metadata.AuthorNickname,
					PostId:            metadata.PostID,
					CommentId:         metadata.CommentID,
					ReplyId:           metadata.ReplyID,
					IsOfficialClub:    metadata.IsOfficialClub,
				},
			},
		},
	}, nil
}
