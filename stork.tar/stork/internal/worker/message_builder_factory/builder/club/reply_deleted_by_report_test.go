package club

import (
	"testing"

	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"github.com/stretchr/testify/require"
)

func TestReplyDeletedByReportGetType(t *testing.T) {
	builder := replyDeletedByReportMessageBuilder{}
	require.Equal(t, model.TypeClub, builder.GetType())
}

func TestReplyDeletedByReportGetSubtype(t *testing.T) {
	builder := replyDeletedByReportMessageBuilder{}
	require.Equal(
		t, model.SubtypeReplyDeletedByReport, builder.GetSubtype())
}
