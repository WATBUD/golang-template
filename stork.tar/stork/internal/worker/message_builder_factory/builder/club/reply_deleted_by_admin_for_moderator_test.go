package club

import (
	"testing"

	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"github.com/stretchr/testify/require"
)

func TestReplyDeletedByAdminForModeratorGetType(t *testing.T) {
	builder := replyDeletedByAdminForModeratorMessageBuilder{}
	require.Equal(t, model.TypeClub, builder.GetType())
}

func TestReplyDeletedByAdminForModeratorGetSubtype(t *testing.T) {
	builder := replyDeletedByAdminForModeratorMessageBuilder{}
	require.Equal(
		t, model.SubtypeReplyDeletedByAdminForModerator, builder.GetSubtype())
}
