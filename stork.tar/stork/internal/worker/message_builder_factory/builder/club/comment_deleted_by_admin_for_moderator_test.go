package club

import (
	"testing"

	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"github.com/stretchr/testify/require"
)

func TestCommentDeletedByAdminForModeratorGetType(t *testing.T) {
	builder := commentDeletedByAdminForModeratorMessageBuilder{}
	require.Equal(t, model.TypeClub, builder.GetType())
}

func TestCommentDeletedByAdminForModeratorGetSubtype(t *testing.T) {
	builder := commentDeletedByAdminForModeratorMessageBuilder{}
	require.Equal(
		t, model.SubtypeCommentDeletedByAdminForModerator, builder.GetSubtype())
}
