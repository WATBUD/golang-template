package club

import (
	pb "beango.visualstudio.com/BeanGoAPP/stork/internal/gen/pb/notification"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/worker/message_builder_factory/builder"
	"github.com/pkg/errors"
	"google.golang.org/protobuf/proto"
)

func init() {
	messageBuilder := &newPostMessageBuilder{}
	builder.AllBuilders = append(
		builder.AllBuilders, messageBuilder)
}

type newPostMessageBuilder struct {
}

func (b *newPostMessageBuilder) GetType() string {
	return model.TypeClub
}

func (b *newPostMessageBuilder) GetSubtype() string {
	return model.SubtypeNewPost
}

func (b *newPostMessageBuilder) Build(
	notification *model.Notification,
) (proto.Message, error) {
	metadata := model.NewPostMetadata{}
	err := builder.MarshalMetadata(notification.Metadata, &metadata)
	if err != nil {
		return nil, errors.Wrap(err, "convert metadata error")
	}

	return &pb.Notification{
		Id:           notification.RequestID,
		Type:         pb.NotificationType_TypeClub,
		SubType:      pb.NotificationSubtype_SubtypeNewPost,
		ThumbnailUri: notification.ThumbnailURI,
		CreatedTime:  notification.CreatedTime,
		Metadata: &pb.NotificationMetadata{
			MetadataOneof: &pb.NotificationMetadata_ClubNewPost{
				ClubNewPost: &pb.ClubNewPostMetadata{
					ClubId:            metadata.ClubID,
					ClubName:          metadata.ClubName,
					AuthorRealAliasId: metadata.AuthorRealAliasID,
					AuthorNickname:    metadata.AuthorNickname,
					PostId:            metadata.PostID,
					Content:           metadata.Content,
					IsOfficialClub:    metadata.IsOfficialClub,
				},
			},
		},
	}, nil
}
