package club

import (
	pb "beango.visualstudio.com/BeanGoAPP/stork/internal/gen/pb/notification"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/worker/message_builder_factory/builder"
	"github.com/pkg/errors"
	"google.golang.org/protobuf/proto"
)

func init() {
	messageBuilder := &commentDeletedByAdminMessageBuilder{}
	builder.AllBuilders = append(
		builder.AllBuilders, messageBuilder)
}

type commentDeletedByAdminMessageBuilder struct {
}

func (b *commentDeletedByAdminMessageBuilder) GetType() string {
	return model.TypeClub
}

func (b *commentDeletedByAdminMessageBuilder) GetSubtype() string {
	return model.SubtypeCommentDeletedByAdmin
}

func (b *commentDeletedByAdminMessageBuilder) Build(
	notification *model.Notification,
) (proto.Message, error) {
	metadata := model.CommentDeletedByAdminMetadata{}
	err := builder.MarshalMetadata(notification.Metadata, &metadata)
	if err != nil {
		return nil, errors.Wrap(err, "convert metadata error")
	}

	return &pb.Notification{
		Id:           notification.RequestID,
		Type:         pb.NotificationType_TypeClub,
		SubType:      pb.NotificationSubtype_SubtypeCommentDeletedByAdmin,
		ThumbnailUri: notification.ThumbnailURI,
		CreatedTime:  notification.CreatedTime,
		Metadata: &pb.NotificationMetadata{
			MetadataOneof: &pb.NotificationMetadata_CommentDeletedByAdmin{
				CommentDeletedByAdmin: &pb.CommentDeletedByAdminMetadata{
					ClubId:         metadata.ClubID,
					ClubName:       metadata.ClubName,
					IsOfficialClub: metadata.IsOfficialClub,
				},
			},
		},
	}, nil
}
