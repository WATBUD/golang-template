package club

import (
	"testing"

	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"github.com/stretchr/testify/require"
)

func TestCommentDeletedByModeratorGetType(t *testing.T) {
	builder := commentDeletedByModeratorMessageBuilder{}
	require.Equal(t, model.TypeClub, builder.GetType())
}

func TestCommentDeletedByModeratorGetSubtype(t *testing.T) {
	builder := commentDeletedByModeratorMessageBuilder{}
	require.Equal(
		t, model.SubtypeCommentDeletedByModerator, builder.GetSubtype())
}
