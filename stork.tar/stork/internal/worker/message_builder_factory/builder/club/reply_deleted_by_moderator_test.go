package club

import (
	"testing"

	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"github.com/stretchr/testify/require"
)

func TestReplyDeletedByModeratorGetType(t *testing.T) {
	builder := replyDeletedByModeratorMessageBuilder{}
	require.Equal(t, model.TypeClub, builder.GetType())
}

func TestReplyDeletedByModeratorGetSubtype(t *testing.T) {
	builder := replyDeletedByModeratorMessageBuilder{}
	require.Equal(
		t, model.SubtypeReplyDeletedByModerator, builder.GetSubtype())
}
