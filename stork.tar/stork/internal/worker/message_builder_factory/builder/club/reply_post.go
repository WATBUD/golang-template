package club

import (
	pb "beango.visualstudio.com/BeanGoAPP/stork/internal/gen/pb/notification"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/worker/message_builder_factory/builder"
	"github.com/pkg/errors"
	"google.golang.org/protobuf/proto"
)

func init() {
	messageBuilder := &replyPostMessageBuilder{}
	builder.AllBuilders = append(
		builder.AllBuilders, messageBuilder)
}

type replyPostMessageBuilder struct {
}

func (b *replyPostMessageBuilder) GetType() string {
	return model.TypeClub
}

func (b *replyPostMessageBuilder) GetSubtype() string {
	return model.SubtypeReplyPost
}

func (b *replyPostMessageBuilder) Build(
	notification *model.Notification,
) (proto.Message, error) {
	metadata := model.ReplyPostMetadata{}
	err := builder.MarshalMetadata(notification.Metadata, &metadata)
	if err != nil {
		return nil, errors.Wrap(err, "convert metadata error")
	}

	return &pb.Notification{
		Id:           notification.RequestID,
		Type:         pb.NotificationType_TypeClub,
		SubType:      pb.NotificationSubtype_SubtypeReplyPost,
		ThumbnailUri: notification.ThumbnailURI,
		CreatedTime:  notification.CreatedTime,
		Metadata: &pb.NotificationMetadata{
			MetadataOneof: &pb.NotificationMetadata_ClubReplyPost{
				ClubReplyPost: &pb.ClubReplyPostMetadata{
					ClubId:            metadata.ClubID,
					ClubName:          metadata.ClubName,
					AuthorRealAliasId: metadata.AuthorRealAliasID,
					AuthorNickname:    metadata.AuthorNickname,
					PostId:            metadata.PostID,
					CommentId:         metadata.CommentID,
					IsOfficialClub:    metadata.IsOfficialClub,
				},
			},
		},
	}, nil
}
