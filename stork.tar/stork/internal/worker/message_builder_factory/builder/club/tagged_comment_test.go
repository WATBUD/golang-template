package club

import (
	"testing"

	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"github.com/stretchr/testify/require"
)

func TestTaggedCommentGetType(t *testing.T) {
	builder := taggedCommentMessageBuilder{}
	require.Equal(t, model.TypeClub, builder.GetType())
}

func TestTaggedCommentGetSubtype(t *testing.T) {
	builder := taggedCommentMessageBuilder{}
	require.Equal(
		t, model.SubtypeTaggedComment, builder.GetSubtype())
}
