package club

import (
	"testing"

	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"github.com/stretchr/testify/require"
)

func TestCommentDeletedByReportGetType(t *testing.T) {
	builder := commentDeletedByReportMessageBuilder{}
	require.Equal(t, model.TypeClub, builder.GetType())
}

func TestCommentDeletedByReportGetSubtype(t *testing.T) {
	builder := commentDeletedByReportMessageBuilder{}
	require.Equal(
		t, model.SubtypeCommentDeletedByReport, builder.GetSubtype())
}
