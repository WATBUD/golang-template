package club

import (
	pb "beango.visualstudio.com/BeanGoAPP/stork/internal/gen/pb/notification"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/worker/message_builder_factory/builder"
	"github.com/pkg/errors"
	"google.golang.org/protobuf/proto"
)

func init() {
	messageBuilder := &postDeletedByAdminMessageBuilder{}
	builder.AllBuilders = append(
		builder.AllBuilders, messageBuilder)
}

type postDeletedByAdminMessageBuilder struct {
}

func (b *postDeletedByAdminMessageBuilder) GetType() string {
	return model.TypeClub
}

func (b *postDeletedByAdminMessageBuilder) GetSubtype() string {
	return model.SubtypePostDeletedByAdmin
}

func (b *postDeletedByAdminMessageBuilder) Build(
	notification *model.Notification,
) (proto.Message, error) {
	metadata := model.PostDeletedByAdminMetadata{}
	err := builder.MarshalMetadata(notification.Metadata, &metadata)
	if err != nil {
		return nil, errors.Wrap(err, "convert metadata error")
	}

	return &pb.Notification{
		Id:           notification.RequestID,
		Type:         pb.NotificationType_TypeClub,
		SubType:      pb.NotificationSubtype_SubtypePostDeletedByAdmin,
		ThumbnailUri: notification.ThumbnailURI,
		CreatedTime:  notification.CreatedTime,
		Metadata: &pb.NotificationMetadata{
			MetadataOneof: &pb.NotificationMetadata_PostDeletedByAdmin{
				PostDeletedByAdmin: &pb.PostDeletedByAdminMetadata{
					ClubId:         metadata.ClubID,
					ClubName:       metadata.ClubName,
					IsOfficialClub: metadata.IsOfficialClub,
				},
			},
		},
	}, nil
}
