package club

import (
	pb "beango.visualstudio.com/BeanGoAPP/stork/internal/gen/pb/notification"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/worker/message_builder_factory/builder"
	"github.com/pkg/errors"
	"google.golang.org/protobuf/proto"
)

func init() {
	messageBuilder := &taggedCommentMessageBuilder{}
	builder.AllBuilders = append(
		builder.AllBuilders, messageBuilder)
}

type taggedCommentMessageBuilder struct {
}

func (b *taggedCommentMessageBuilder) GetType() string {
	return model.TypeClub
}

func (b *taggedCommentMessageBuilder) GetSubtype() string {
	return model.SubtypeTaggedComment
}

func (b *taggedCommentMessageBuilder) Build(
	notification *model.Notification,
) (proto.Message, error) {
	metadata := model.ReplyPostMetadata{}
	err := builder.MarshalMetadata(notification.Metadata, &metadata)
	if err != nil {
		return nil, errors.Wrap(err, "convert metadata error")
	}

	return &pb.Notification{
		Id:           notification.RequestID,
		Type:         pb.NotificationType_TypeClub,
		SubType:      pb.NotificationSubtype_SubtypeTaggedComment,
		ThumbnailUri: notification.ThumbnailURI,
		CreatedTime:  notification.CreatedTime,
		Metadata: &pb.NotificationMetadata{
			MetadataOneof: &pb.NotificationMetadata_ClubTaggedComment{
				ClubTaggedComment: &pb.ClubTaggedCommentMetadata{
					ClubId:            metadata.ClubID,
					ClubName:          metadata.ClubName,
					AuthorRealAliasId: metadata.AuthorRealAliasID,
					AuthorNickname:    metadata.AuthorNickname,
					PostId:            metadata.PostID,
					CommentId:         metadata.CommentID,
					IsOfficialClub:    metadata.IsOfficialClub,
				},
			},
		},
	}, nil
}
