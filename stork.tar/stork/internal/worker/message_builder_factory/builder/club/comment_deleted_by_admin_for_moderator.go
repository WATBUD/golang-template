package club

import (
	pb "beango.visualstudio.com/BeanGoAPP/stork/internal/gen/pb/notification"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/worker/message_builder_factory/builder"
	"github.com/pkg/errors"
	"google.golang.org/protobuf/proto"
)

func init() {
	messageBuilder := &commentDeletedByAdminForModeratorMessageBuilder{}
	builder.AllBuilders = append(
		builder.AllBuilders, messageBuilder)
}

type commentDeletedByAdminForModeratorMessageBuilder struct {
}

func (b *commentDeletedByAdminForModeratorMessageBuilder) GetType() string {
	return model.TypeClub
}

func (b *commentDeletedByAdminForModeratorMessageBuilder) GetSubtype() string {
	return model.SubtypeCommentDeletedByAdminForModerator
}

func (b *commentDeletedByAdminForModeratorMessageBuilder) Build(
	notification *model.Notification,
) (proto.Message, error) {
	metadata := model.CommentDeletedByAdminForModeratorMetadata{}
	err := builder.MarshalMetadata(notification.Metadata, &metadata)
	if err != nil {
		return nil, errors.Wrap(err, "convert metadata error")
	}

	return &pb.Notification{
		Id:           notification.RequestID,
		Type:         pb.NotificationType_TypeClub,
		SubType:      pb.NotificationSubtype_SubtypeCommentDeletedByAdminForModerator,
		ThumbnailUri: notification.ThumbnailURI,
		CreatedTime:  notification.CreatedTime,
		Metadata: &pb.NotificationMetadata{
			MetadataOneof: &pb.NotificationMetadata_CommentDeletedByAdminForModerator{
				CommentDeletedByAdminForModerator: &pb.CommentDeletedByAdminForModeratorMetadata{
					ClubId:         metadata.ClubID,
					ClubName:       metadata.ClubName,
					Content:        metadata.Content,
					IsOfficialClub: metadata.IsOfficialClub,
				},
			},
		},
	}, nil
}
