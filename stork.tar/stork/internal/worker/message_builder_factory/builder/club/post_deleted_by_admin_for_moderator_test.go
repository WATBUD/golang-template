package club

import (
	"testing"

	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"github.com/stretchr/testify/require"
)

func TestPostDeletedByAdminForModeratorMessageGetType(t *testing.T) {
	builder := postDeletedByAdminForModeratorMessageBuilder{}
	require.Equal(t, model.TypeClub, builder.GetType())
}

func TestPostDeletedByAdminForModeratorMessageGetSubtype(t *testing.T) {
	builder := postDeletedByAdminForModeratorMessageBuilder{}
	require.Equal(
		t, model.SubtypePostDeletedByAdminForModerator, builder.GetSubtype())
}
