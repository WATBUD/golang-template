package club

import (
	"testing"

	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"github.com/stretchr/testify/require"
)

func TestPostDeletedByAdminMessageGetType(t *testing.T) {
	builder := postDeletedByAdminMessageBuilder{}
	require.Equal(t, model.TypeClub, builder.GetType())
}

func TestPostDeletedByAdminMessageGetSubtype(t *testing.T) {
	builder := postDeletedByAdminMessageBuilder{}
	require.Equal(
		t, model.SubtypePostDeletedByAdmin, builder.GetSubtype())
}
