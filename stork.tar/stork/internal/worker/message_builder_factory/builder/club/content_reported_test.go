package club

import (
	"testing"

	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"github.com/stretchr/testify/require"
)

func TestContentReportedGetType(t *testing.T) {
	builder := contentReportedMessageBuilder{}
	require.Equal(t, model.TypeClub, builder.GetType())
}

func TestContentReportedGetSubtype(t *testing.T) {
	builder := contentReportedMessageBuilder{}
	require.Equal(
		t, model.SubtypeContentReported, builder.GetSubtype())
}
