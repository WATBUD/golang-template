package club

import (
	"testing"

	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"github.com/stretchr/testify/require"
)

func TestPostDeletedByModeratorMessageGetType(t *testing.T) {
	builder := postDeletedByModeratorMessageBuilder{}
	require.Equal(t, model.TypeClub, builder.GetType())
}

func TestPostDeletedByModeratorMessageGetSubtype(t *testing.T) {
	builder := postDeletedByModeratorMessageBuilder{}
	require.Equal(
		t, model.SubtypePostDeletedByModerator, builder.GetSubtype())
}
