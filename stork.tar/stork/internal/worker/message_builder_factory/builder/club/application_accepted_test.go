package club

import (
	"testing"

	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"github.com/stretchr/testify/require"
)

func TestApplicationAcceptedGetType(t *testing.T) {
	builder := applicationAcceptedMessageBuilder{}
	require.Equal(t, model.TypeClub, builder.GetType())
}

func TestApplicationAcceptedGetSubtype(t *testing.T) {
	builder := applicationAcceptedMessageBuilder{}
	require.Equal(
		t, model.SubtypeApplicationAccepted, builder.GetSubtype())
}
