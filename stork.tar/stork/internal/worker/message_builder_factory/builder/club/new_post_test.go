package club

import (
	"testing"

	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"github.com/stretchr/testify/require"
)

func TestNewPostGetType(t *testing.T) {
	builder := newPostMessageBuilder{}
	require.Equal(t, model.TypeClub, builder.GetType())
}

func TestNewPostGetSubtype(t *testing.T) {
	builder := newPostMessageBuilder{}
	require.Equal(
		t, model.SubtypeNewPost, builder.GetSubtype())
}
