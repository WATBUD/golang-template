package club

import (
	"testing"

	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"github.com/stretchr/testify/require"
)

func TestReplyCommentGetType(t *testing.T) {
	builder := replyCommentMessageBuilder{}
	require.Equal(t, model.TypeClub, builder.GetType())
}

func TestReplyCommentGetSubtype(t *testing.T) {
	builder := replyCommentMessageBuilder{}
	require.Equal(
		t, model.SubtypeReplyComment, builder.GetSubtype())
}
