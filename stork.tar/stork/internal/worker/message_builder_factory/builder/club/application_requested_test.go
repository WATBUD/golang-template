package club

import (
	"testing"

	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"github.com/stretchr/testify/require"
)

func TestApplicationRequestedGetType(t *testing.T) {
	builder := applicationRequestedMessageBuilder{}
	require.Equal(t, model.TypeClub, builder.GetType())
}

func TestApplicationRequestedGetSubtype(t *testing.T) {
	builder := applicationRequestedMessageBuilder{}
	require.Equal(
		t, model.SubtypeApplicationRequested, builder.GetSubtype())
}
