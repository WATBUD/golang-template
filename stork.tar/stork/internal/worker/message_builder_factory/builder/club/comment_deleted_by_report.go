package club

import (
	pb "beango.visualstudio.com/BeanGoAPP/stork/internal/gen/pb/notification"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/worker/message_builder_factory/builder"
	"github.com/pkg/errors"
	"google.golang.org/protobuf/proto"
)

func init() {
	messageBuilder := &commentDeletedByReportMessageBuilder{}
	builder.AllBuilders = append(
		builder.AllBuilders, messageBuilder)
}

type commentDeletedByReportMessageBuilder struct {
}

func (b *commentDeletedByReportMessageBuilder) GetType() string {
	return model.TypeClub
}

func (b *commentDeletedByReportMessageBuilder) GetSubtype() string {
	return model.SubtypeCommentDeletedByReport
}

func (b *commentDeletedByReportMessageBuilder) Build(
	notification *model.Notification,
) (proto.Message, error) {
	metadata := model.CommentDeletedByReportMetadata{}
	err := builder.MarshalMetadata(notification.Metadata, &metadata)
	if err != nil {
		return nil, errors.Wrap(err, "convert metadata error")
	}

	return &pb.Notification{
		Id:           notification.RequestID,
		Type:         pb.NotificationType_TypeClub,
		SubType:      pb.NotificationSubtype_SubtypeCommentDeletedByReport,
		ThumbnailUri: notification.ThumbnailURI,
		CreatedTime:  notification.CreatedTime,
		Metadata: &pb.NotificationMetadata{
			MetadataOneof: &pb.NotificationMetadata_CommentDeletedByReport{
				CommentDeletedByReport: &pb.CommentDeletedByReportMetadata{
					ClubId:         metadata.ClubID,
					ClubName:       metadata.ClubName,
					IsOfficialClub: metadata.IsOfficialClub,
				},
			},
		},
	}, nil
}
