package club

import (
	"testing"

	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"github.com/stretchr/testify/require"
)

func TestCommentDeletedByAdminGetType(t *testing.T) {
	builder := commentDeletedByAdminMessageBuilder{}
	require.Equal(t, model.TypeClub, builder.GetType())
}

func TestCommentDeletedByAdminGetSubtype(t *testing.T) {
	builder := commentDeletedByAdminMessageBuilder{}
	require.Equal(
		t, model.SubtypeCommentDeletedByAdmin, builder.GetSubtype())
}
