package club

import (
	pb "beango.visualstudio.com/BeanGoAPP/stork/internal/gen/pb/notification"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/worker/message_builder_factory/builder"
	"github.com/pkg/errors"
	"google.golang.org/protobuf/proto"
)

func init() {
	messageBuilder := &replyDeletedByAdminForModeratorMessageBuilder{}
	builder.AllBuilders = append(
		builder.AllBuilders, messageBuilder)
}

type replyDeletedByAdminForModeratorMessageBuilder struct {
}

func (b *replyDeletedByAdminForModeratorMessageBuilder) GetType() string {
	return model.TypeClub
}

func (b *replyDeletedByAdminForModeratorMessageBuilder) GetSubtype() string {
	return model.SubtypeReplyDeletedByAdminForModerator
}

func (b *replyDeletedByAdminForModeratorMessageBuilder) Build(
	notification *model.Notification,
) (proto.Message, error) {
	metadata := model.ReplyDeletedByAdminForModeratorMetadata{}
	err := builder.MarshalMetadata(notification.Metadata, &metadata)
	if err != nil {
		return nil, errors.Wrap(err, "convert metadata error")
	}

	return &pb.Notification{
		Id:           notification.RequestID,
		Type:         pb.NotificationType_TypeClub,
		SubType:      pb.NotificationSubtype_SubtypeReplyDeletedByAdminForModerator,
		ThumbnailUri: notification.ThumbnailURI,
		CreatedTime:  notification.CreatedTime,
		Metadata: &pb.NotificationMetadata{
			MetadataOneof: &pb.NotificationMetadata_ReplyDeletedByAdminForModerator{
				ReplyDeletedByAdminForModerator: &pb.ReplyDeletedByAdminForModeratorMetadata{
					ClubId:         metadata.ClubID,
					ClubName:       metadata.ClubName,
					Content:        metadata.Content,
					IsOfficialClub: metadata.IsOfficialClub,
				},
			},
		},
	}, nil
}
