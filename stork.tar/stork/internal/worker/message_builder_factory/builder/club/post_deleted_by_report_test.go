package club

import (
	"testing"

	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"github.com/stretchr/testify/require"
)

func TestPostDeletedByReportMessageGetType(t *testing.T) {
	builder := postDeletedByReportMessageBuilder{}
	require.Equal(t, model.TypeClub, builder.GetType())
}

func TestPostDeletedByReportMessageGetSubtype(t *testing.T) {
	builder := postDeletedByReportMessageBuilder{}
	require.Equal(
		t, model.SubtypePostDeletedByReport, builder.GetSubtype())
}
