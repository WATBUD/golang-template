package builder

import (
	"encoding/json"
	"fmt"

	messagebuilderfactory "beango.visualstudio.com/BeanGoAPP/stork/internal/worker/message_builder_factory" // nolint: lll
)

var AllBuilders = []messagebuilderfactory.MessageBuilder{}

func MarshalMetadata(
	raw interface{}, metadata interface{},
) error {
	switch raw := raw.(type) {
	case map[string]interface{}:
		data, err := json.Marshal(raw)
		if err != nil {
			return err
		}
		return json.Unmarshal(data, metadata)
	default:
		return fmt.Errorf("invalid metadata(type=%s)", raw)
	}
}
