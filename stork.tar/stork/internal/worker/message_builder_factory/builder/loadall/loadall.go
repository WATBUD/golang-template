package loadall

import (
	_ "beango.visualstudio.com/BeanGoAPP/stork/internal/worker/message_builder_factory/builder/club" // nolint: lll
)
