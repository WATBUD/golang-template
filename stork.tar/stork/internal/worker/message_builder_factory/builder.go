package messagebuilderfactory

import (
	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"google.golang.org/protobuf/proto"
)

type MessageBuilder interface {
	GetType() string
	GetSubtype() string
	Build(notification *model.Notification) (proto.Message, error)
}
