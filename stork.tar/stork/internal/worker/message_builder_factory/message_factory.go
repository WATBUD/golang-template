package messagebuilderfactory

import (
	"fmt"

	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"github.com/sirupsen/logrus"
)

func NewMessageBuilderFactory(
	builders []MessageBuilder, logger logrus.FieldLogger,
) (MessageFatcory, error) {
	builderMap := make(map[string]MessageBuilder, len(builders))
	for _, builder := range builders {
		type_ := builder.GetType() // nolint: revive
		subtype := builder.GetSubtype()
		key := makeMapKey(type_, subtype)
		existBuilder, ok := builderMap[key]
		if ok {
			logger.Errorf("key conflict %s, original builder %+v", key, existBuilder)
			return nil, fmt.Errorf("key conflict")
		}

		builderMap[key] = builder
		logger.Infof("load %s builder to message factoy", key)
	}
	return &redisMessageFactory{
		builderMap: builderMap,
		logger:     logger,
	}, nil
}

type MessageFatcory interface {
	Make(notification *model.Notification) (MessageBuilder, error)
}

type redisMessageFactory struct {
	builderMap map[string]MessageBuilder
	logger     logrus.FieldLogger
}

func (f *redisMessageFactory) Make(
	notification *model.Notification,
) (MessageBuilder, error) {
	key := makeMapKey(notification.Type, notification.Subtype)
	builder, ok := f.builderMap[key]
	if !ok {
		return nil, fmt.Errorf("unknown type: %s, subtype: %s",
			notification.Type, notification.Subtype)
	}
	f.logger.Debugf("use %s builder for notification %d", key, notification.RequestID)
	return builder, nil
}

func makeMapKey(type_ string, subtype string) string { // nolint: revive
	return fmt.Sprintf("%s:%s", type_, subtype)
}
