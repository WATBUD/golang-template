package worker

import (
	"fmt"
	"testing"
	"time"

	"beango.visualstudio.com/BeanGoAPP/caerus/database"
	"beango.visualstudio.com/BeanGoAPP/caerus/redis"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/kafka"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/repository"
	messagebuilderfactory "beango.visualstudio.com/BeanGoAPP/stork/internal/worker/message_builder_factory"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/worker/message_builder_factory/builder"
	_ "beango.visualstudio.com/BeanGoAPP/stork/internal/worker/message_builder_factory/builder/loadall"
	"github.com/golang/mock/gomock"
	"github.com/sirupsen/logrus"
	"github.com/stretchr/testify/require"
)

func TestWorkerRunOnce(t *testing.T) {
	notification := &model.Notification{
		RequestID:          12345,
		TargetRealAliasIDs: []int64{1, 2, 3},
		Type:               "foo",
		Subtype:            "bar",
		ThumbnailURI:       "xx",
		CreatedTime:        time.Now().UnixMilli(),
	}
	kafkaEvent := &model.KafkaEvent{
		Data: notification,
		Type: model.KafkaEventTypeNewMessage,
	}
	worker, factory, builder, db, redis, consumer, repo, _ := newWorkerAndMocks(t, t)
	consumer.EXPECT().Consume(time.Second).Return(kafkaEvent, nil)
	factory.EXPECT().Make(notification).Return(builder, nil)
	builder.EXPECT().Build(notification).Return(nil, nil)
	redis.EXPECT().Publish("channel:user:1", gomock.Any()).Return(nil)
	redis.EXPECT().Publish("channel:user:2", gomock.Any()).Return(nil)
	redis.EXPECT().Publish("channel:user:3", gomock.Any()).Return(nil)
	db.EXPECT().GetWriteConnection().Return(nil, nil).AnyTimes()
	repo.EXPECT().InsertMany(nil, notification)
	repo.EXPECT().UpdateStatus(nil, int64(12345), []int64{1, 2, 3}, repository.StatusSent)

	err := worker.RunOnce()
	require.NoError(t, err)
}

func TestWorkerRunStop(t *testing.T) {
	worker, _, _, _, _, _, _, _ := newWorkerAndMocks(t, t)

	worker.Stop()
	err := worker.Run()
	require.NoError(t, err)
}

func TestWorkerRunOnce_PartialPublished(t *testing.T) {
	notification := &model.Notification{
		RequestID:          12345,
		TargetRealAliasIDs: []int64{1, 2, 3},
		Type:               "foo",
		Subtype:            "bar",
		ThumbnailURI:       "xx",
		CreatedTime:        time.Now().UnixMilli(),
	}
	kafkaEvent := &model.KafkaEvent{
		Data: notification,
		Type: model.KafkaEventTypeNewMessage,
	}
	worker, factory, builder, db, redis, consumer, repo, _ := newWorkerAndMocks(t, t)
	consumer.EXPECT().Consume(time.Second).Return(kafkaEvent, nil)
	factory.EXPECT().Make(notification).Return(builder, nil)
	builder.EXPECT().Build(notification).Return(nil, nil)
	redis.EXPECT().Publish("channel:user:1", gomock.Any()).Return(nil)
	redis.EXPECT().Publish("channel:user:2", gomock.Any()).Return(fmt.Errorf("xx"))
	redis.EXPECT().Publish("channel:user:3", gomock.Any()).Return(nil)
	db.EXPECT().GetWriteConnection().Return(nil, nil).AnyTimes()
	repo.EXPECT().InsertMany(nil, notification)
	repo.EXPECT().UpdateStatus(nil, int64(12345), []int64{1, 3}, repository.StatusSent)

	err := worker.RunOnce()
	require.NoError(t, err)
}

func TestWorkerRunOnce_NoOnePublished(t *testing.T) {
	notification := &model.Notification{
		RequestID:          12345,
		TargetRealAliasIDs: []int64{1, 2, 3},
		Type:               "foo",
		Subtype:            "bar",
		ThumbnailURI:       "xx",
		CreatedTime:        time.Now().UnixMilli(),
	}
	kafkaEvent := &model.KafkaEvent{
		Data: notification,
		Type: model.KafkaEventResend,
	}
	worker, factory, builder, _, redis, consumer, _, _ := newWorkerAndMocks(t, t)
	consumer.EXPECT().Consume(time.Second).Return(kafkaEvent, nil)
	factory.EXPECT().Make(notification).Return(builder, nil)
	builder.EXPECT().Build(notification).Return(nil, nil)
	redis.EXPECT().Publish(gomock.Any(), gomock.Any()).Times(3).Return(fmt.Errorf("err"))

	err := worker.RunOnce()
	require.NoError(t, err)
}

func TestWorkerRunOnceFail(t *testing.T) {
	t.Run("factoryMakeError", testWorkerRunOnce_FactoryMakeError)
	t.Run("builderError", testWorkerRunOnce_BuilderError)
	t.Run("getConnError", testWorkerRunOnce_GetConnError)
	t.Run("repoError", testWorkerRunOnce_RepoError)
}

func testWorkerRunOnce_FactoryMakeError(t *testing.T) {
	notification := &model.Notification{
		RequestID:          12345,
		TargetRealAliasIDs: []int64{1, 2, 3},
		Type:               "foo",
		Subtype:            "bar",
		ThumbnailURI:       "xx",
		CreatedTime:        time.Now().UnixMilli(),
	}
	kafkaEvent := &model.KafkaEvent{
		Data: notification,
		Type: model.KafkaEventTypeNewMessage,
	}
	worker, factory, _, db, _, consumer, repo, _ := newWorkerAndMocks(t, t)
	consumer.EXPECT().Consume(time.Second).Return(kafkaEvent, nil)
	db.EXPECT().GetWriteConnection().Return(nil, nil)
	repo.EXPECT().InsertMany(nil, notification)
	factory.EXPECT().Make(notification).Return(nil, fmt.Errorf("err"))

	err := worker.RunOnce()
	require.Error(t, err)
}

func testWorkerRunOnce_BuilderError(t *testing.T) {
	notification := &model.Notification{
		RequestID:          12345,
		TargetRealAliasIDs: []int64{1, 2, 3},
		Type:               "foo",
		Subtype:            "bar",
		ThumbnailURI:       "xx",
		CreatedTime:        time.Now().UnixMilli(),
	}
	kafkaEvent := &model.KafkaEvent{
		Data: notification,
		Type: model.KafkaEventTypeNewMessage,
	}
	worker, factory, builder, db, _, consumer, repo, _ := newWorkerAndMocks(t, t)
	consumer.EXPECT().Consume(time.Second).Return(kafkaEvent, nil)
	db.EXPECT().GetWriteConnection().Return(nil, nil)
	repo.EXPECT().InsertMany(nil, notification)
	factory.EXPECT().Make(notification).Return(builder, nil)
	builder.EXPECT().Build(notification).Return(nil, fmt.Errorf("err"))

	err := worker.RunOnce()
	require.Error(t, err)
}

func testWorkerRunOnce_GetConnError(t *testing.T) {
	notification := &model.Notification{
		RequestID:          12345,
		TargetRealAliasIDs: []int64{1},
		Type:               "foo",
		Subtype:            "bar",
		ThumbnailURI:       "xx",
		CreatedTime:        time.Now().UnixMilli(),
	}
	kafkaEvent := &model.KafkaEvent{
		Data: notification,
		Type: model.KafkaEventTypeNewMessage,
	}
	worker, _, _, db, _, consumer, _, _ := newWorkerAndMocks(t, t)
	consumer.EXPECT().Consume(time.Second).Return(kafkaEvent, nil)
	db.EXPECT().GetWriteConnection().Return(nil, fmt.Errorf("err"))

	err := worker.RunOnce()
	require.Error(t, err)
}

func testWorkerRunOnce_RepoError(t *testing.T) {
	notification := &model.Notification{
		RequestID:          12345,
		TargetRealAliasIDs: []int64{1},
		Type:               "foo",
		Subtype:            "bar",
		ThumbnailURI:       "xx",
		CreatedTime:        time.Now().UnixMilli(),
	}
	kafkaEvent := &model.KafkaEvent{
		Data: notification,
		Type: model.KafkaEventTypeNewMessage,
	}
	worker, factory, builder, db, redis, consumer, repo, _ := newWorkerAndMocks(t, t)
	consumer.EXPECT().Consume(time.Second).Return(kafkaEvent, nil)
	factory.EXPECT().Make(notification).Return(builder, nil)
	builder.EXPECT().Build(notification).Return(nil, nil)
	redis.EXPECT().Publish(gomock.Any(), gomock.Any()).Return(nil)
	db.EXPECT().GetWriteConnection().Return(nil, nil).AnyTimes()
	repo.EXPECT().InsertMany(nil, notification)
	repo.EXPECT().UpdateStatus(
		nil, int64(12345), []int64{1}, repository.StatusSent).Return(fmt.Errorf("err"))

	err := worker.RunOnce()
	require.Error(t, err)
}

func newWorkerAndMocks(
	t require.TestingT, r gomock.TestReporter,
) (Worker, *messagebuilderfactory.MockMessageFatcory, *messagebuilderfactory.MockMessageBuilder,
	*database.MockDatabase, *redis.MockRedis,
	*kafka.MockNotificationConsumer, *repository.MockNotificationRepo,
	logrus.FieldLogger,
) {
	logger := logrus.New()
	ctrl := gomock.NewController(r)
	factory := messagebuilderfactory.NewMockMessageFatcory(ctrl)
	builder := messagebuilderfactory.NewMockMessageBuilder(ctrl)
	db := database.NewMockDatabase(ctrl)
	redis := redis.NewMockRedis(ctrl)
	consumer := kafka.NewMockNotificationConsumer(ctrl)
	repo := repository.NewMockNotificationRepo(ctrl)

	worker := NewWorker(factory, db, redis, consumer, repo, logger)
	return worker, factory, builder, db, redis, consumer, repo, logger
}

func BenchmarkWorker(b *testing.B) {
	notification := makeNotificationWithMultipleAliasIDs(1000)
	_, _, _, db, redis, consumer, repo, logger := newWorkerAndMocks(b, b)
	consumer.EXPECT().Consume(gomock.Any()).AnyTimes().Return(notification, nil)
	redis.EXPECT().Publish(gomock.Any(), gomock.Any()).AnyTimes().Return(nil)
	db.EXPECT().GetWriteConnection().AnyTimes().Return(nil, nil).AnyTimes()
	repo.EXPECT().InsertMany(nil, notification)
	repo.EXPECT().UpdateStatus(gomock.Any(), gomock.Any(), gomock.Any(), gomock.Any()).AnyTimes().Return(nil)
	require.NotEmpty(b, builder.AllBuilders)
	factory, err := messagebuilderfactory.NewMessageBuilderFactory(builder.AllBuilders, logger)
	require.NoError(b, err)
	worker := NewWorker(factory, db, redis, consumer, repo, logger)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		err := worker.RunOnce()
		require.NoError(b, err)
	}
}

func makeNotificationWithMultipleAliasIDs(count int) *model.Notification {
	notification := &model.Notification{
		RequestID:          time.Now().UnixNano(),
		TargetRealAliasIDs: make([]int64, 0, count),
		Type:               model.TypeClub,
		Subtype:            model.SubtypeNewPost,
		ThumbnailURI:       "http://foobar.com/baz.png",
		CreatedTime:        time.Now().UnixMilli(),
		Metadata: map[string]interface{}{
			"club_id":              time.Now().UnixNano(),
			"club_name":            "123",
			"author_Real_alias_id": time.Now().UnixNano(),
			"author_nickname":      "xxx",
			"post_id":              time.Now().UnixNano(),
			"is_official_club":     true,
		},
	}
	for i := 0; i < count; i++ {
		notification.TargetRealAliasIDs = append(notification.TargetRealAliasIDs, time.Now().UnixNano())
	}
	return notification
}
