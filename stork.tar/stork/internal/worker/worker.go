package worker

import (
	"encoding/base64"
	"encoding/json"
	"fmt"
	"time"

	"beango.visualstudio.com/BeanGoAPP/caerus/database"
	"beango.visualstudio.com/BeanGoAPP/caerus/redis"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/kafka"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/repository"
	messagebuilderfactory "beango.visualstudio.com/BeanGoAPP/stork/internal/worker/message_builder_factory" // nolint: lll
	"github.com/pkg/errors"
	"github.com/sirupsen/logrus"
	"google.golang.org/protobuf/proto"
)

func NewWorker(
	factory messagebuilderfactory.MessageFatcory,
	db database.Database,
	redis redis.Redis, consumer kafka.NotificationConsumer,
	repo repository.NotificationRepo,
	logger logrus.FieldLogger,
) Worker {
	return &redisPublishWorker{
		factory:  factory,
		db:       db,
		consumer: consumer,
		redis:    redis,
		repo:     repo,
		logger:   logger,
	}
}

type Worker interface {
	Run() error
	RunOnce() error
	Stop()
}

type redisPublishWorker struct {
	factory  messagebuilderfactory.MessageFatcory
	db       database.Database
	consumer kafka.NotificationConsumer
	redis    redis.Redis
	repo     repository.NotificationRepo
	logger   logrus.FieldLogger
	stop     bool
}

func (w *redisPublishWorker) Stop() {
	w.stop = true
	w.logger.Infof("redis publish worker stopping")
}

func (w *redisPublishWorker) Run() error {
	w.logger.Infof("redis publish worker started")
	for !w.stop {
		err := w.RunOnce()
		if err != nil {
			w.logger.Fatalf("worker error: %s", err)
		}
	}
	w.logger.Infof("redis publish worker stopped")
	return nil
}

func (w *redisPublishWorker) RunOnce() error {
	kafkaEvent, err := w.consumer.Consume(time.Second)
	if err != nil {
		return errors.Wrap(err, "consume error")
	} else if kafkaEvent == nil {
		return nil
	}

	notification := kafkaEvent.Data
	if kafkaEvent.Type == model.KafkaEventTypeNewMessage {
		if err = w.insertNotification(notification); err != nil {
			return errors.Wrap(err, "insert to db error")
		}
	}
	message, err := w.prepareMessage(notification)
	if err != nil {
		return errors.Wrap(err, "prepare message error")
	}

	sentRealAliasIDs := make([]int64, 0, len(notification.TargetRealAliasIDs))
	for _, realAliasID := range notification.TargetRealAliasIDs {
		err := w.publishToRedis(realAliasID, message)
		if err != nil {
			w.logger.Warnf("unable to notify %d due to %s", realAliasID, err)
			continue
		}
		w.logger.Infof("notification %d been sent to user %d", notification.RequestID, realAliasID)
		sentRealAliasIDs = append(sentRealAliasIDs, realAliasID)
	}

	if len(sentRealAliasIDs) == 0 {
		return nil
	}

	err = w.updateStatus(notification.RequestID, sentRealAliasIDs, repository.StatusSent)
	if err != nil {
		return errors.Wrap(err, "update status error")
	}
	return nil
}

func (w *redisPublishWorker) publishToRedis(realAliasID int64, message []byte) error {
	channel := w.getChannelName(realAliasID)
	err := w.redis.Publish(channel, message)
	if err != nil {
		return errors.Wrap(err, "publish to redis error")
	}
	return nil
}

func (w *redisPublishWorker) insertNotification(
	notification *model.Notification,
) error {
	conn, err := w.db.GetWriteConnection()
	if err != nil {
		return errors.Wrap(err, "get db connection error")
	}

	err = w.repo.InsertMany(conn, notification)
	if err != nil {
		return errors.Wrap(err, "execute repo error")
	}
	return nil
}

func (w *redisPublishWorker) updateStatus(
	requestID int64, realAliasIDs []int64, status int,
) error {
	conn, err := w.db.GetWriteConnection()
	if err != nil {
		return errors.Wrap(err, "get db connection error")
	}

	err = w.repo.UpdateStatus(conn, requestID, realAliasIDs, status)
	if err != nil {
		return errors.Wrap(err, "execute repo error")
	}
	return nil
}

func (w *redisPublishWorker) getChannelName(realAliasID int64) string {
	return fmt.Sprintf("channel:user:%d", realAliasID)
}

func (w *redisPublishWorker) prepareMessage(
	notification *model.Notification,
) ([]byte, error) {
	id := notification.RequestID
	w.logger.Infof("get notification %d", id)

	builder, err := w.factory.Make(notification)
	if err != nil {
		w.logger.Errorf(
			"ignore notification %d because get message builder error: %s",
			id, err)
		return nil, errors.Wrap(err, "get message builder error")
	}

	payload, err := builder.Build(notification)
	if err != nil {
		w.logger.Errorf(
			"ignore notification %d because build message error: %s",
			id, err)
		return nil, errors.Wrap(err, "build message error")
	}

	message, err := w.serializeMessage(payload)
	if err != nil {
		w.logger.Errorf(
			"ignore notification %d because serialize error: %s",
			id, err)
		return nil, errors.Wrap(err, "serialize message error")
	}
	return message, nil
}

func (w *redisPublishWorker) serializeMessage(message proto.Message) ([]byte, error) {
	packetBytes, err := proto.Marshal(message)
	if err != nil {
		return nil, errors.Wrap(err, "proto marshal error")
	}
	payload := base64.StdEncoding.EncodeToString(packetBytes)

	socketEvent := map[string]interface{}{
		"path":    "v1/notification",
		"payload": payload,
	}

	data, err := json.Marshal(socketEvent)
	if err != nil {
		return nil, errors.Wrap(err, "marshal socket event error")
	}
	return data, nil
}
