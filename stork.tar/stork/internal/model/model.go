package model

const (
	TypeClub = "club"

	SubtypeNewPost                           = "new_post"
	SubtypeReplyPost                         = "reply_post"
	SubtypeReplyComment                      = "reply_comment"
	SubtypeTaggedComment                     = "tagged_comment"
	SubtypeApplicationAccepted               = "application_accepted"
	SubtypeApplicationRequested              = "application_requested"
	SubtypeContentReported                   = "content_reported"
	SubtypeRoleToModerator                   = "role_to_moderator"
	SubtypePostDeletedByReport               = "post_deleted_by_report"
	SubtypePostDeletedByModerator            = "post_deleted_by_moderator"
	SubtypePostDeletedByAdmin                = "post_deleted_by_admin"
	SubtypePostDeletedByAdminForModerator    = "post_deleted_by_admin_for_moderator"
	SubtypeCommentDeletedByReport            = "comment_deleted_by_report"
	SubtypeCommentDeletedByModerator         = "comment_deleted_by_moderator"
	SubtypeCommentDeletedByAdmin             = "comment_deleted_by_admin"
	SubtypeCommentDeletedByAdminForModerator = "comment_deleted_by_admin_for_moderator"
	SubtypeReplyDeletedByReport              = "reply_deleted_by_report"
	SubtypeReplyDeletedByModerator           = "reply_deleted_by_moderator"
	SubtypeReplyDeletedByAdmin               = "reply_deleted_by_admin"
	SubtypeReplyDeletedByAdminForModerator   = "reply_deleted_by_admin_for_moderator"
)

const (
	KafkaEventTypeNewMessage = iota
	KafkaEventResend
)

type KafkaEvent struct {
	Data *Notification `json:"data"`
	Type int32         `json:"type"`
}

type Notification struct {
	RequestID          int64       `json:"request_id"`
	TargetRealAliasIDs []int64     `json:"target_real_alias_ids"`
	Type               string      `json:"type"`
	Subtype            string      `json:"subtype"`
	ThumbnailURI       string      `json:"thumbnail_uri"`
	CreatedTime        int64       `json:"created_time"`
	Metadata           interface{} `json:"metadata"`
}

type NewPostMetadata struct {
	ClubID            int64  `json:"club_id"`
	ClubName          string `json:"club_name"`
	AuthorRealAliasID int64  `json:"author_real_alias_id"`
	AuthorNickname    string `json:"author_nickname"`
	PostID            int64  `json:"post_id"`
	Content           string `json:"content"`
	IsOfficialClub    bool   `json:"is_official_club"`
}

type ReplyPostMetadata struct {
	ClubID            int64  `json:"club_id"`
	ClubName          string `json:"club_name"`
	AuthorRealAliasID int64  `json:"author_real_alias_id"`
	AuthorNickname    string `json:"author_nickname"`
	PostID            int64  `json:"post_id"`
	CommentID         string `json:"comment_id"`
	IsOfficialClub    bool   `json:"is_official_club"`
}

type ReplyCommentMetadata struct {
	ClubID            int64  `json:"club_id"`
	ClubName          string `json:"club_name"`
	AuthorRealAliasID int64  `json:"author_real_alias_id"`
	AuthorNickname    string `json:"author_nickname"`
	PostID            int64  `json:"post_id"`
	CommentID         string `json:"comment_id"`
	ReplyID           string `json:"reply_id"`
	IsOfficialClub    bool   `json:"is_official_club"`
}

type TaggedCommentMetadata struct {
	ClubID            int64  `json:"club_id"`
	ClubName          string `json:"club_name"`
	AuthorRealAliasID int64  `json:"author_real_alias_id"`
	AuthorNickname    string `json:"author_nickname"`
	PostID            int64  `json:"post_id"`
	CommentID         string `json:"comment_id"`
	IsOfficialClub    bool   `json:"is_official_club"`
}

type ApplicationAcceptedMetadata struct {
	ClubID         int64  `json:"club_id"`
	ClubName       string `json:"club_name"`
	IsOfficialClub bool   `json:"is_official_club"`
}

type ApplicationRequestedMetadata struct {
	ClubID         int64  `json:"club_id"`
	ClubName       string `json:"club_name"`
	IsOfficialClub bool   `json:"is_official_club"`
}

type ContentReportedMetadata struct {
	ClubID         int64  `json:"club_id"`
	ClubName       string `json:"club_name"`
	IsOfficialClub bool   `json:"is_official_club"`
}

type ContentRoleToModeratorMetadata struct {
	ClubID         int64  `json:"club_id"`
	ClubName       string `json:"club_name"`
	IsOfficialClub bool   `json:"is_official_club"`
}

type PostDeletedByReportMetadata struct {
	ClubID         int64  `json:"club_id"`
	ClubName       string `json:"club_name"`
	PostID         int64  `json:"post_id"`
	ReportJudgeID  int64  `json:"report_judge_id"`
	IsOfficialClub bool   `json:"is_official_club"`
}

type PostDeletedByModeratorMetadata struct {
	ClubID         int64  `json:"club_id"`
	ClubName       string `json:"club_name"`
	PostID         int64  `json:"post_id"`
	IsOfficialClub bool   `json:"is_official_club"`
}

type PostDeletedByAdminMetadata struct {
	ClubID         int64  `json:"club_id"`
	ClubName       string `json:"club_name"`
	PostID         int64  `json:"post_id"`
	IsOfficialClub bool   `json:"is_official_club"`
}

type PostDeletedByAdminForModeratorMetadata struct {
	ClubID         int64  `json:"club_id"`
	ClubName       string `json:"club_name"`
	PostID         int64  `json:"post_id"`
	Content        string `json:"content"`
	IsOfficialClub bool   `json:"is_official_club"`
}

type CommentDeletedByReportMetadata struct {
	ClubID         int64  `json:"club_id"`
	ClubName       string `json:"club_name"`
	CommentID      string `json:"comment_id"`
	ReportJudgeID  int64  `json:"report_judge_id"`
	IsOfficialClub bool   `json:"is_official_club"`
}

type CommentDeletedByModeratorMetadata struct {
	ClubID         int64  `json:"club_id"`
	ClubName       string `json:"club_name"`
	CommentID      string `json:"comment_id"`
	IsOfficialClub bool   `json:"is_official_club"`
}

type CommentDeletedByAdminMetadata struct {
	ClubID         int64  `json:"club_id"`
	ClubName       string `json:"club_name"`
	CommentID      string `json:"comment_id"`
	IsOfficialClub bool   `json:"is_official_club"`
}

type CommentDeletedByAdminForModeratorMetadata struct {
	ClubID         int64  `json:"club_id"`
	ClubName       string `json:"club_name"`
	CommentID      string `json:"comment_id"`
	Content        string `json:"content"`
	IsOfficialClub bool   `json:"is_official_club"`
}

type ReplyDeletedByReportMetadata struct {
	ClubID         int64  `json:"club_id"`
	ClubName       string `json:"club_name"`
	ReplyID        string `json:"reply_id"`
	ReportJudgeID  int64  `json:"report_judge_id"`
	IsOfficialClub bool   `json:"is_official_club"`
}

type ReplyDeletedByModeratorMetadata struct {
	ClubID         int64  `json:"club_id"`
	ClubName       string `json:"club_name"`
	ReplyID        string `json:"reply_id"`
	IsOfficialClub bool   `json:"is_official_club"`
}

type ReplyDeletedByAdminMetadata struct {
	ClubID         int64  `json:"club_id"`
	ClubName       string `json:"club_name"`
	ReplyID        string `json:"reply_id"`
	IsOfficialClub bool   `json:"is_official_club"`
}

type ReplyDeletedByAdminForModeratorMetadata struct {
	ClubID         int64  `json:"club_id"`
	ClubName       string `json:"club_name"`
	ReplyID        string `json:"reply_id"`
	Content        string `json:"content"`
	IsOfficialClub bool   `json:"is_official_club"`
}
