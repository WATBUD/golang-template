package kafka

import (
	"bytes"
	"encoding/json"
	"fmt"
	"time"

	"beango.visualstudio.com/BeanGoAPP/caerus/kafka"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"github.com/pkg/errors"
	"github.com/sirupsen/logrus"
)

func NewNotificationConsumer(
	hosts []string, topic string, groupID string, logger logrus.FieldLogger,
) NotificationConsumer {
	consumer := kafka.NewConsumer(hosts, topic, groupID, logger)
	return &notificadtionConsumer{consumer, logger}
}

type NotificationConsumer interface {
	Consume(timeout time.Duration) (*model.KafkaEvent, error)
	Close() error
}

type notificadtionConsumer struct {
	consumer kafka.Consumer
	logger   logrus.FieldLogger
}

func (c *notificadtionConsumer) Consume(timeout time.Duration) (*model.KafkaEvent, error) {
	data, err := c.consumer.Consume(timeout)
	if err != nil {
		return nil, errors.Wrap(err, "consume error")
	} else if data == nil {
		return nil, nil
	}

	kafkaEvent := &model.KafkaEvent{}
	decoder := json.NewDecoder(bytes.NewBuffer(data))
	decoder.UseNumber()
	if err = decoder.Decode(kafkaEvent); err != nil {
		return nil, errors.Wrap(err, "unmarshal data error")
	}
	return kafkaEvent, nil
}

func (c *notificadtionConsumer) Close() error {
	return c.consumer.Close()
}

func NewNotificationProducer(
	hosts []string, topic string, logger logrus.FieldLogger,
) NotificationProducer {
	producer := kafka.NewProducer(hosts, topic, logger)
	return &notificationProducer{producer, logger}
}

type NotificationProducer interface {
	Produce(notification *model.KafkaEvent) error
	Close() error
}

type notificationProducer struct {
	producer kafka.Producer
	logger   logrus.FieldLogger
}

func (p *notificationProducer) Produce(kafkaEvent *model.KafkaEvent) error {
	data, err := json.Marshal(kafkaEvent)
	if err != nil {
		return errors.Wrap(err, "marshal err")
	}
	notification := kafkaEvent.Data
	key := fmt.Sprintf("%s:%s", notification.Type, notification.Subtype)
	return p.producer.Produce(key, data)
}

func (p *notificationProducer) Close() error {
	return p.producer.Close()
}
