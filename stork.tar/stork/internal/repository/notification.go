package repository

import (
	"bytes"
	"encoding/json"
	"fmt"
	"strings"

	"beango.visualstudio.com/BeanGoAPP/caerus/database"
	"beango.visualstudio.com/BeanGoAPP/stork/internal/model"
	"github.com/jackc/pgtype"
	"github.com/lib/pq"
	"github.com/pkg/errors"
	"github.com/sirupsen/logrus"
)

const (
	StatusUnsend = iota
	StatusSent
)

func NewNotificationRepo(logger logrus.FieldLogger) NotificationRepo {
	return &notificationRepo{
		table:  "notification",
		logger: logger,
	}
}

type NotificationRepo interface {
	InsertMany(conn database.Connection, notification *model.Notification) error
	UpdateStatus(
		conn database.Connection, requestID int64, realAliasIDs []int64, status int,
	) error
	Find(
		conn database.Connection, realAliasID int64, lastNotificationID int64,
		createdTime int64, limit int,
	) ([]*model.Notification, error)
}

type notificationRepo struct {
	table  string
	logger logrus.FieldLogger
}

func (r *notificationRepo) InsertMany(
	conn database.Connection, notification *model.Notification,
) error {
	keys := []string{
		"request_id",
		"real_alias_id",
		"type",
		"subtype",
		"thumbnail_uri",
		"metadata",
		"created_time",
	}
	sql := fmt.Sprintf(`INSERT INTO %s (%s) 
								(SELECT * FROM UNNEST(
										?::bigint[],
										?::bigint[],
										?::varchar[],
										?::varchar[],
										?::varchar[],
										?::jsonb[],
										?::bigint[]))`, r.table, strings.Join(keys, ","))
	metadata, err := json.Marshal(notification.Metadata)
	if err != nil {
		return errors.Wrap(err, "marshal metadata error")
	}
	requestIDs := make([]int64, 0, len(notification.TargetRealAliasIDs))
	realAliasIDs := make([]int64, 0, len(notification.TargetRealAliasIDs))
	types := make([]string, 0, len(notification.TargetRealAliasIDs))
	subTypes := make([]string, 0, len(notification.TargetRealAliasIDs))
	thumbnailUris := make([]string, 0, len(notification.TargetRealAliasIDs))
	metadataList := make([][]byte, 0, len(notification.TargetRealAliasIDs))
	createdTimes := make([]int64, 0, len(notification.TargetRealAliasIDs))
	for _, targetRealAliasID := range notification.TargetRealAliasIDs {
		n := notification
		requestIDs = append(requestIDs, n.RequestID)
		realAliasIDs = append(realAliasIDs, targetRealAliasID)
		types = append(types, n.Type)
		subTypes = append(subTypes, n.Subtype)
		thumbnailUris = append(thumbnailUris, n.ThumbnailURI)
		metadataList = append(metadataList, metadata)
		createdTimes = append(createdTimes, n.CreatedTime)
	}
	var metas pgtype.JSONBArray
	if err = metas.Set(metadataList); err != nil {
		return fmt.Errorf("insert notification error: %w", err)
	}
	_, err = conn.Exec(conn.Rebind(sql), pq.Array(requestIDs), pq.Array(realAliasIDs),
		pq.Array(types), pq.Array(subTypes), pq.Array(thumbnailUris), metas,
		pq.Array(createdTimes))
	if err != nil {
		return fmt.Errorf("insert notification error: %w", err)
	}
	return nil
}

func (r *notificationRepo) UpdateStatus(
	conn database.Connection, requestID int64, realAliasIDs []int64, status int,
) error {
	args := make([]interface{}, 0)
	sql := fmt.Sprintf(
		"UPDATE %s SET status=? WHERE status!=? AND request_id=? AND real_alias_id IN (%s)",
		r.table, r.genQuestionMarks(len(realAliasIDs)))
	args = append(args, status)
	args = append(args, status)
	args = append(args, requestID)
	for _, realAliasID := range realAliasIDs {
		args = append(args, realAliasID)
	}
	result, err := conn.Exec(conn.Rebind(sql), args...)
	if err != nil {
		return errors.Wrap(err, "execute sql error")
	}

	if count, err := result.RowsAffected(); err == nil {
		r.logger.Debugf("update status effect %d rows for request %d", count, requestID)
	}
	return nil
}

func (r *notificationRepo) genQuestionMarks(count int) string {
	questionMarks := make([]string, 0, count)
	for i := 0; i < count; i++ {
		questionMarks = append(questionMarks, "?")
	}
	return strings.Join(questionMarks, ",")
}

func (r *notificationRepo) Find(
	conn database.Connection, realAliasID int64, notificationLastID int64,
	createdTime int64, limit int,
) ([]*model.Notification, error) {
	sql := fmt.Sprintf(`
        SELECT
            request_id, real_alias_id, type, subtype, thumbnail_uri,
            metadata, created_time, status
        FROM %s
        WHERE real_alias_id = ? AND request_id > ? AND created_time > ?
        ORDER BY request_id DESC LIMIT ?`,
		r.table)
	rows, err := conn.Queryx(conn.Rebind(sql),
		realAliasID, notificationLastID, createdTime, limit)
	if err != nil {
		return nil, errors.Wrap(err, "query error")
	}

	notifications := make([]*model.Notification, 0)
	defer rows.Close()
	for rows.Next() {
		raw := &notificationInDB{}
		rawMetadata := []byte{}
		err := rows.Scan(
			&raw.RequestID, &raw.RealAliasID,
			&raw.Type, &raw.Subtype, &raw.ThumbnailURI,
			&rawMetadata, &raw.CreatedTime, &raw.Status)
		if err != nil {
			return nil, errors.Wrap(err, "convert struct error")
		}

		metadata, err := r.makeMetadata(rawMetadata)
		if err != nil {
			return nil, errors.Wrap(err, "make metadata error")
		}
		raw.Metadata = metadata

		notification, err := r.makeNotification(raw)
		if err != nil {
			return nil, errors.Wrap(err, "make notification error")
		}

		notifications = append(notifications, notification)
	}
	return notifications, nil
}

func (r *notificationRepo) makeMetadata(raw []byte) (map[string]interface{}, error) {
	// NOTE: use decoder with number to prevent convert number into float64 instead
	// of int64 then data will be overflowed
	metadata := make(map[string]interface{})
	decoder := json.NewDecoder(bytes.NewReader(raw))
	decoder.UseNumber()
	err := decoder.Decode(&metadata)
	return metadata, err
}

func (r *notificationRepo) makeNotification(raw *notificationInDB) (*model.Notification, error) { // nolint: unparam
	return &model.Notification{
		RequestID:          raw.RequestID,
		TargetRealAliasIDs: []int64{raw.RealAliasID},
		Type:               raw.Type,
		Subtype:            raw.Subtype,
		ThumbnailURI:       raw.ThumbnailURI,
		Metadata:           raw.Metadata,
		CreatedTime:        raw.CreatedTime,
	}, nil
}

type notificationInDB struct {
	RequestID    int64       `db:"request_id"`
	RealAliasID  int64       `db:"real_alias_id"`
	Type         string      `db:"type"`
	Subtype      string      `db:"subtype"`
	ThumbnailURI string      `db:"thumbnail_uri"`
	Metadata     interface{} `db:"metadata"`
	CreatedTime  int64       `db:"created_time"`
	Status       int         `db:"status"`
}
