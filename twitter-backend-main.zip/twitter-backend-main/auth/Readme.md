# Auth Service

## Functions

- Create/Update/Delete User
- login and logout
- Generate JWT (access-Token & refresh-Token)
- Validate JWT
