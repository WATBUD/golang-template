# Tweet Service

## Functions

- GetTweetById
- GetTweetByUsername
- CreateTweet
- DeleteTweet
- LikeTweet
- DislikeTweet
- ReTweet
- Delete-ReTweet
<hr>
